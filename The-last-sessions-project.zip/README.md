# The Last Sessions — проект игры (не один HTML)

Папка `www/` — сама игра:
- index.html, style.css, game.js — код
- assets/ — картинки и музыка (сюда кладёшь любые большие файлы, лимита как у одного HTML нет)

## Как получить APK без ПК
1. Создай репозиторий на github.com и загрузи в него ВСЕ файлы этого проекта (с папками .github и www).
2. Открой вкладку Actions → Build APK → Run workflow.
3. Через 5–10 минут открой готовый запуск и скачай the-last-sessions-apk (внутри app-debug.apk).
4. Установи APK на телефон.

## Проверка на ПК
Запусти в папке www:  python -m http.server 8000  и открой http://localhost:8000
(файл index.html двойным кликом не откроется — браузер блокирует картинки).
