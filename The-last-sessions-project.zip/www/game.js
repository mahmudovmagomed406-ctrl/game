
const $=id=>document.getElementById(id);
const R=new THREE.WebGLRenderer({canvas:$('g'),antialias:false});
const scene=new THREE.Scene(),cam=new THREE.PerspectiveCamera(75,1,.05,60);
cam.rotation.order='YXZ';scene.add(cam);
scene.background=new THREE.Color(0x8c7d58);scene.fog=new THREE.Fog(0x8c7d58,12,42);
function size(){const a=innerWidth/Math.max(1,innerHeight);R.setSize(Math.round(224*a),224,false);cam.aspect=a;cam.updateProjectionMatrix()}
addEventListener('resize',size);size();

function tex(n,draw){const c=document.createElement('canvas');c.width=c.height=n;draw(c.getContext('2d'),n);const t=new THREE.CanvasTexture(c);t.magFilter=t.minFilter=THREE.NearestFilter;t.wrapS=t.wrapT=THREE.RepeatWrapping;return t}
const rnd=Math.random;
const mkWall=c=>tex(64,(x,n)=>{x.fillStyle=c;x.fillRect(0,0,n,n);x.strokeStyle='#26282a';x.lineWidth=2;x.beginPath();x.moveTo(0,1);x.lineTo(n,2);x.moveTo(1,0);x.lineTo(2,n);x.moveTo(0,n/2);x.lineTo(n,n/2+1);x.moveTo(n/2,0);x.lineTo(n/2-1,n);x.stroke()});
const wallT=mkWall('#77796f'),wallG=mkWall('#5f6158');
const floorT=tex(32,(x,n)=>{x.fillStyle='#3d3d3a';x.fillRect(0,0,n,n);x.fillStyle='#262624';x.fillRect(0,0,n,1);x.fillRect(0,0,1,n)});
const bandT=tex(16,(x,n)=>{x.fillStyle='#cdbf9f';x.fillRect(0,0,n,n);x.fillStyle='#a3956f';for(let i=-n;i<n*2;i+=4)for(let k=0;k<n;k++)x.fillRect((i+k)%n,k,1,1);x.fillStyle='#8a0f0f';for(let i=0;i<9;i++)x.fillRect(rnd()*n|0,rnd()*n|0,2,2)});

// --- level ---
const W=[],B=(x,z,w,d)=>{W.push({a:x-w/2,b:x+w/2,c:z-d/2,d:z+d/2});const t=(W.length%2?wallG:wallT).clone();t.needsUpdate=true;t.repeat.set(Math.max(w,d)/4,1);const m=new THREE.Mesh(new THREE.BoxGeometry(w,4,d),new THREE.MeshBasicMaterial({map:t}));m.position.set(x,2,z);scene.add(m)};
[[0,-20,41,1],[0,20,41,1],[-20,0,1,41],[20,0,1,41],[-12.25,4,.5,32.5],[12.25,4,.5,32.5],
 [-8.25,-12,8.3,.5],[-8.25,-4,8.3,.5],[-8.25,4,8.3,.5],[-8.25,12,8.3,.5],[8.25,-12,8.3,.5],[8.25,-4,8.3,.5],[8.25,4,8.3,.5],
 [-4.25,-16,.5,8],[4.25,-16,.5,8],[4.25,7.25,.5,6.5],[4.25,16.75,.5,6.5]].forEach(a=>B(...a));
const barT=tex(32,(x,n)=>{x.clearRect(0,0,n,n);x.fillStyle='#1c1c1e';x.fillRect(12,0,7,n);x.fillStyle='#4a4a4e';x.fillRect(13,0,2,n);x.fillStyle='#1c1c1e';x.fillRect(0,0,n,3)});
function bars(x,z0,z1){W.push({a:x-.15,b:x+.15,c:z0,d:z1});const l=z1-z0,t=barT.clone();t.needsUpdate=true;t.repeat.set(l/.9,1);const m=new THREE.Mesh(new THREE.PlaneGeometry(l,3.8),new THREE.MeshBasicMaterial({map:t,transparent:true,alphaTest:.5,side:THREE.DoubleSide}));m.rotation.y=Math.PI/2;m.position.set(x,1.9,(z0+z1)/2);scene.add(m)}
function prop(x,y,z,w,h,d,col){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),new THREE.MeshBasicMaterial({color:col}));m.position.set(x,y,z);scene.add(m)}
[-8,0,8,16].forEach(c=>{bars(-4.25,c-4,c-1.3);bars(-4.25,c+1.3,c+4);prop(-10.6,.35,c-2.2,2.2,.7,4.2,0x4a4036);prop(-5.6,.4,c+2.8,.8,.8,.8,0x777770)});
[-8,0].forEach(c=>{bars(4.25,c-4,c-1.3);bars(4.25,c+1.3,c+4);prop(10.6,.35,c-2.2,2.2,.7,4.2,0x4a4036);prop(5.6,.4,c+2.8,.8,.8,.8,0x777770)});
prop(9,.45,17,4,.9,1.2,0x3a2a1a);prop(6,.9,18.5,.9,1.8,1,0x2a3a3a);
const CAMS=[];function camMk(x,z,ry){const g=new THREE.Group(),dk=new THREE.MeshBasicMaterial({color:0x222226});g.add(new THREE.Mesh(new THREE.BoxGeometry(.5,.4,.9),dk));const led=new THREE.Mesh(new THREE.BoxGeometry(.14,.14,.14),new THREE.MeshBasicMaterial({color:0xff1111,fog:false}));led.position.set(0,.05,.5);g.add(led);g.position.set(x,3.5,z);scene.add(g);CAMS.push({g,led,ry,ph:rnd()*6})}
camMk(3.6,14,-.7);camMk(-3.6,3,.7);camMk(3.6,-6,-.7);camMk(0,-19,0);
function plane(y,tt){const t=floorT.clone();t.needsUpdate=true;t.repeat.set(20,20);const m=new THREE.Mesh(new THREE.PlaneGeometry(40,40),new THREE.MeshBasicMaterial({map:t,color:tt}));m.rotation.x=y>0?Math.PI/2:-Math.PI/2;m.position.y=y;scene.add(m)}
plane(0,0xffffff);plane(4,0x555555);
function collide(p,r){for(const w of W){const cx=Math.max(w.a,Math.min(p.x,w.b)),cz=Math.max(w.c,Math.min(p.z,w.d));let dx=p.x-cx,dz=p.z-cz;const d2=dx*dx+dz*dz;if(d2<r*r){if(d2>1e-6){const d=Math.sqrt(d2),k=(r-d)/d;p.x+=dx*k;p.z+=dz*k}else p.x+=r}}}

// --- NPCs ---
const bub=$('bub'),npcs=[];
const CT={};
function ePose(n,i){
  const L=(a,b,t)=>a+(b-a)*t,I={l:0,tilt:0,dy:0,leg:0,k:[-12,18],b:[8,-10],kn:-80};
  if(n==='wind'){const t=i/3;return{...I,l:-t*5,tilt:-t*2,k:[L(-12,-145,t),L(18,-170,t)],b:[L(8,25,t),L(-10,-25,t)],kn:L(-80,-172,t)}}
  if(n==='hit')return i===0?{...I,l:5,dy:2,k:[-80,-70],b:[15,5],kn:-70}:{...I,l:8,dy:5,tilt:3,k:[-8,8],b:[20,10],kn:8};
  if(n==='stag'){const t=i/2;return{...I,l:L(-9,-2,t),tilt:L(-5,-1,t),k:[L(-108,-45,t),L(-128,-35,t)],b:[L(105,45,t),L(122,40,t)],kn:L(-125,-40,t)}}
  if(n==='neck'){return{...I,l:i?-2:2,tilt:i?3:-3,k:[-25,-150],b:[25,150],kn:-150}}
  if(n==='kneel')return{...I,hh:30,dy:30,kneel:1,l:i?9:0,tilt:i?8:0,k:[-8,5],b:[8,-5],kn:-90};
  if(n==='lieF')return{...I,k:[-165,-175],b:[165,175],kn:-170};
  if(n==='lieB')return{...I,k:[-75,-85],b:[75,85],kn:-90};
  if(n==='fin'){return i===0?{...I,l:-7,tilt:-7,k:[-50,-30],b:[50,30],kn:-80}:i===1?{...I,l:-3,tilt:-3,k:[-15,-155],b:[15,155],kn:-160}:{...I,l:9,dy:6,tilt:4,k:[-5,-30],b:[5,30],kn:-60}}
  if(n==='walk'){const s=i?1:-1;return{...I,leg:s*.8,k:[-12+s*9,18],b:[8-s*9,-10]}}
  return I}
function charTex(n,i,v){const key=n+i+v;if(CT[key])return CT[key];const o=ePose(n,i);
  const c=document.createElement('canvas');c.width=128;c.height=192;const x=c.getContext('2d');x.translate(16,0);x.lineCap='round';x.lineJoin='round';
  const SK=v===2?'#c8c8c8':'#efd2a8',SH=['#15203a','#2c3a2a','#6f6f6f'][v],CF=v===2?'#444':'#2b8a3e',PA='#151515',R=Math.PI/180;
  let S=[];const seg=(x0,y0,a,len,w,col)=>{const x1=x0+Math.sin(a*R)*len,y1=y0+Math.cos(a*R)*len;S.push([x0,y0,x1,y1,w,col]);return[x1,y1]};
  const flush=()=>{for(const p of S){x.strokeStyle='#000';x.lineWidth=p[4]+3;x.beginPath();x.moveTo(p[0],p[1]);x.lineTo(p[2],p[3]);x.stroke()}
    for(const p of S){x.strokeStyle=p[5];x.lineWidth=p[4];x.beginPath();x.moveTo(p[0],p[1]);x.lineTo(p[2],p[3]);x.stroke()}S=[]};
  const dot=(px,py,r,col)=>{x.beginPath();x.arc(px,py,r,0,7);x.fillStyle=col;x.fill();x.lineWidth=2;x.strokeStyle='#000';x.stroke()};
  const hy=108+(o.hh||0),hx=48+o.l*.3,sy=56+o.dy,sx=48+o.l;
  // legs
  const knees=[];[[-1,o.leg],[1,-o.leg]].forEach(([sd,ph])=>{if(o.kneel){seg(hx+sd*7,hy,0,32,12,PA);seg(hx+sd*7,hy+32,90,8,8,'#0a0a0a');return}const t=ph*26,k=seg(hx+sd*7,hy,t,33,12,PA);knees.push(k);const f=seg(k[0],k[1],t*.3+(t<0?-14:0),33,11,PA);seg(f[0],f[1],90,8,8,'#0a0a0a')});flush();
  knees.forEach(k=>dot(k[0],k[1],5,'#2c2c2c'));
  // torso
  x.beginPath();x.moveTo(sx-17,sy);x.lineTo(sx+17,sy);x.lineTo(hx+12,hy+2);x.lineTo(hx-12,hy+2);x.closePath();x.fillStyle=SH;x.fill();x.lineWidth=3;x.strokeStyle='#000';x.stroke();
  x.fillStyle='#050505';x.fillRect(hx-12,hy-5,24,8);
  // head
  const hd=sx+o.tilt;seg(sx,sy,0,-6,7,SK);flush();
  dot(hd,sy-17,12,v===2?'#c8c8c8':'#f3dcb9');
  if(v===1){x.fillStyle='#000';x.fillRect(hd-6,sy-19,3,2);x.fillRect(hd+3,sy-19,3,2);x.fillStyle='#7f8a94';x.fillRect(hd-11,sy-15,22,9);x.fillStyle='#111';x.fillRect(hd-12,sy-32,24,9);x.fillRect(hd-12,sy-26,26,3)}
  // arms
  const arm=(sd,a,glove,knife)=>{const s0=[sx+sd*16,sy+3],e1=seg(s0[0],s0[1],a[0],19,10,SH),e2=seg(e1[0],e1[1],a[1],5,11,CF),e3=seg(e2[0],e2[1],a[1],15,8,SK);
    if(knife){seg(e3[0],e3[1],o.kn,17,4,'#cfd4d8');}flush();dot(e3[0],e3[1],5.5,'#111')};
  arm(1,o.b,1,0);arm(-1,o.k,1,1);
  const t=new THREE.CanvasTexture(c);t.magFilter=t.minFilter=THREE.NearestFilter;return CT[key]=t}
function eTex(e,nm,fi){const nw=(e.wounds||[]).length+(e.nohead?100:0);if(!nw)return charTex(nm,fi,e.v);
  e.wc=e.wc||{};const k=nm+fi+'_'+nw;if(e.wc[k])return e.wc[k];
  const c=document.createElement('canvas');c.width=128;c.height=192;const x=c.getContext('2d');x.drawImage(charTex(nm,fi,e.v).image,0,0);const o=ePose(nm,fi);
  if(e.nohead){x.globalCompositeOperation='destination-out';x.beginPath();x.arc(64+o.l+o.tilt,39+o.dy,15,0,7);x.fill();x.globalCompositeOperation='source-over';
    x.fillStyle='#8a0f0f';x.strokeStyle='#000';x.lineWidth=2;x.beginPath();x.moveTo(52+o.l,58+o.dy);x.lineTo(55+o.l,50+o.dy);x.lineTo(60+o.l,55+o.dy);x.lineTo(64+o.l,48+o.dy);x.lineTo(70+o.l,55+o.dy);x.lineTo(74+o.l,50+o.dy);x.lineTo(77+o.l,58+o.dy);x.closePath();x.fill();x.stroke();
    x.fillStyle='#b41a1a';x.fillRect(58+o.l,52+o.dy,14,3);x.fillStyle='#e8e0d0';x.fillRect(62+o.l,50+o.dy,4,3);x.fillRect(69+o.l,52+o.dy,3,3)}
  for(const w of e.wounds||[]){
    const f=Math.max(0,Math.min(1,(108-w.y)/52)),wx=64+w.rx+o.l*(.3+.7*f)+(w.y<50?o.tilt:0),wy=w.y+(o.dy||0);
    const g=x.createRadialGradient(wx,wy,0,wx,wy,w.sr);g.addColorStop(0,'rgba(110,0,0,.75)');g.addColorStop(.6,'rgba(90,0,0,.35)');g.addColorStop(1,'rgba(90,0,0,0)');x.fillStyle=g;x.fillRect(wx-w.sr,wy-w.sr,w.sr*2,w.sr*2);
    x.lineCap='round';
    for(let i=0;i<w.nd;i++){const sx=wx+(i-(w.nd-1)/2)*3+w.dj[i],L=w.dl[i];x.strokeStyle=i%2?'#8a0d0d':'#b01515';x.lineWidth=1.4+w.dw*(i?.5:1);x.beginPath();x.moveTo(sx,wy+2);for(let k=1;k<=6;k++)x.lineTo(sx+Math.sin(k*1.3+w.ph+i)*1.2,wy+2+L*k/6);x.stroke();x.fillStyle='#8a0d0d';x.beginPath();x.arc(sx+Math.sin(7.8+w.ph+i)*1.2,wy+2+L,1.2+w.dw*.4,0,7);x.fill()}
    if(w.t==='b'){x.fillStyle='#5a1010';x.beginPath();x.arc(wx,wy,w.r+1.4,0,7);x.fill();x.fillStyle='#1a0303';x.beginPath();x.arc(wx,wy,w.r,0,7);x.fill();x.fillStyle='#000';x.beginPath();x.arc(wx+.3,wy+.3,w.r*.5,0,7);x.fill();
      x.strokeStyle='rgba(60,0,0,.6)';x.lineWidth=1;for(let i=0;i<5;i++){const a=w.ph+i*1.3;x.beginPath();x.moveTo(wx+Math.cos(a)*w.r,wy+Math.sin(a)*w.r);x.lineTo(wx+Math.cos(a)*(w.r+3+i%2*2),wy+Math.sin(a)*(w.r+3+i%2*2));x.stroke()}}
    else if(w.t==='k'){x.save();x.translate(wx,wy);x.rotate(w.ang);x.strokeStyle='#3a0505';x.lineWidth=3.4;x.beginPath();x.moveTo(-w.len,0);x.lineTo(-w.len/3,1);x.lineTo(w.len/3,-1);x.lineTo(w.len,0);x.stroke();x.strokeStyle='#c81414';x.lineWidth=1.4;x.stroke();x.fillStyle='#e03030';for(let i=0;i<4;i++)x.fillRect(-w.len+i*w.len/2,-1,1.4,1.4);x.restore()}
    else{x.save();x.translate(wx,wy);x.rotate(w.ang);x.fillStyle='#2a0303';x.beginPath();x.ellipse(0,0,w.r*.6,w.len*.5,0,0,7);x.fill();x.fillStyle='#000';x.beginPath();x.ellipse(0,0,w.r*.28,w.len*.36,0,0,7);x.fill();x.strokeStyle='#8a0d0d';x.lineWidth=1.2;x.beginPath();x.ellipse(0,0,w.r*.6+1,w.len*.5+1,0,0,7);x.stroke();x.restore()}}
  const t=new THREE.CanvasTexture(c);t.magFilter=t.minFilter=THREE.NearestFilter;return e.wc[k]=t}
function addWound(e,t,h){const nd=t==='s'?3:1+(rnd()*2|0),dl=[],dj=[];for(let i=0;i<nd;i++){dl.push((t==='s'?14:6)+rnd()*(t==='s'?26:22));dj.push((rnd()-.5)*3)}
  (e.wounds=e.wounds||[]).push({t,rx:(rnd()-.5)*20,y:Math.max(14,Math.min(176,(1-h/2.2)*192)),nd,dl,dj,dw:.6+rnd()*1.2,ph:rnd()*6,ang:t==='k'?(rnd()-.5)*2.4:(rnd()-.5)*.6,len:t==='k'?6+rnd()*8:(t==='s'?9+rnd()*4:0),r:t==='b'?1.6+rnd()*1.6:2+rnd()*1.2,sr:t==='s'?13+rnd()*4:(t==='b'?6+rnd()*6:6+rnd()*5)})}
const gmat=[0xe8b89a,0xd9a0a8,0xeeeeee,0x8a1010].map(c=>new THREE.MeshBasicMaterial({color:c}));
function gibs(x,y,z,dx,dz){for(let i=0;i<58;i++){const k=i%4,m=new THREE.Mesh(pg,gmat[k]),big=rnd()<.25?2.2:1;
  m.scale.set((.5+rnd()*1.2)*big,(.4+rnd()*1.0)*big,(k===2?1.6:1)*(.5+rnd()*1.2)*big);m.position.set(x+(rnd()-.5)*.2,y+(rnd()-.5)*.2,z+(rnd()-.5)*.2);
  const sp=rnd()<.55?7:3;m.userData={g:1,v:new THREE.Vector3(dx*sp*(.4+rnd())+(rnd()-.5)*5,1.5+rnd()*5.5,dz*sp*(.4+rnd())+(rnd()-.5)*5),l:2.6};scene.add(m);parts.push(m)}}
function mkNPC(x,z,v,friendly,type){
  const g=new THREE.Group();
  const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:charTex('idle',0,v)}));sp.scale.set(1.47,2.2,1);sp.position.y=1.1;sp.userData.c=0xffffff;g.add(sp);
  g.position.set(x,0,z);scene.add(g);
  const el=document.createElement('div');bub.appendChild(el);
  const n={g,sp,ms:[sp],v,pose:'idle',type:type||'enemy',aggro:0,par:0,p:g.position,el,until:0,hp:(type||'enemy')==='enemy'?4:3,dead:false,friendly,stun:0,cd:1+rnd(),wind:0,flash:0,bark:3+rnd()*5,fall:0};
  npcs.push(n);return n}
function say(n,t,dur){n.el.textContent=t;n.el.style.display='block';n.until=now+dur}
const tip=$('tip');let tipT=0;
function toast(t,d){tip.textContent=t;tip.style.display='block';tipT=now+d}

// --- blood ---
const pg=new THREE.BoxGeometry(.08,.08,.08),parts=[],decals=[];
const pm=[0x8a0f0f,0xb3170f,0x5a0808].map(c=>new THREE.MeshBasicMaterial({color:c}));
function blood(x,y,z,n,dx,dz){for(let i=0;i<n;i++){const m=new THREE.Mesh(pg,pm[i%3]);m.position.set(x,y,z);m.userData={v:new THREE.Vector3(dx*3+(rnd()-.5)*4,rnd()*4,dz*3+(rnd()-.5)*4),l:1.2};scene.add(m);parts.push(m)}}
const dm=new THREE.MeshBasicMaterial({color:0x5a0000}),dgeo=new THREE.PlaneGeometry(1,1);
function decal(x,z){const m=new THREE.Mesh(dgeo,dm);const s=.3+rnd()*.6;m.scale.set(s,s,1);m.rotation.x=-Math.PI/2;m.position.set(x,.01+rnd()*.005,z);scene.add(m);decals.push(m);if(decals.length>60)scene.remove(decals.shift())}

// --- hands (camera children) ---
const hm=new THREE.MeshBasicMaterial({map:bandT,fog:false,depthTest:false});
const km=new THREE.MeshBasicMaterial({color:0xc9d2d8,fog:false,depthTest:false}),hd=new THREE.MeshBasicMaterial({color:0x2a1a10,fog:false,depthTest:false});
function bx(p,geo,mat,x,y,z,rx=0){const m=new THREE.Mesh(new THREE.BoxGeometry(...geo),mat);m.position.set(x,y,z);m.rotation.x=rx;m.renderOrder=999+(bx.n=(bx.n||0)+1);p.add(m);return m}
const RH=new THREE.Group(),LH=new THREE.Group();cam.add(RH,LH);
bx(RH,[.13,.13,.55],hm,0,-.05,.2,.3);bx(RH,[.15,.15,.16],hm,0,.02,-.1);bx(RH,[.04,.04,.16],hd,0,.05,-.12);
bx(RH,[.03,.07,.34],km,0,.05,-.36);bx(RH,[.02,.04,.08],km,0,.05,-.56);
bx(LH,[.13,.13,.55],hm,0,-.05,.2,.3);bx(LH,[.15,.15,.16],hm,0,.02,-.1);
RH.clear();LH.clear();
const RB64='assets/rb64.png',LB64='assets/lb64.png';
function handPlane(b64,w,h,ro){const t=new THREE.TextureLoader().load(b64);t.magFilter=t.minFilter=THREE.LinearFilter;t.generateMipmaps=false;const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:t,transparent:true,fog:false,depthTest:false}));m.renderOrder=ro;return m}
RH.add(handPlane(RB64,.73,.271,1201));LH.add(handPlane(LB64,.313,.347,1200));

const FB_L64='assets/fb_l64.png';
const FB_R64='assets/fb_r64.png';
const F_RH=new THREE.Group(),F_LH=new THREE.Group();cam.add(F_RH,F_LH);
F_RH.add(handPlane(FB_R64,.62,.42,1201));F_LH.add(handPlane(FB_L64,.62,.32,1200));
F_RH.position.set(.48,-.30,-.55);F_LH.position.set(-.48,-.28,-.55);
F_RH.visible=false;F_LH.visible=false;
RH.position.set(.343,-.28,-.55);LH.position.set(-.332,-.242,-.55);
const PG=new THREE.Group();cam.add(PG);PG.visible=false;
const GUN_IDLE_B64='assets/gun_idle_b64.png';
const GUN_FIRE_B64='assets/gun_fire_b64.png';
function gunPlane(b64,w,h,ro){const t=new THREE.TextureLoader().load(b64);t.magFilter=t.minFilter=THREE.LinearFilter;t.generateMipmaps=false;const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:t,transparent:true,fog:false,depthTest:false}));m.renderOrder=ro;return m}
const G_IDLE=gunPlane(GUN_IDLE_B64,1.15,.74,1205);const G_FIRE=gunPlane(GUN_FIRE_B64,1.15,.435,1205);G_FIRE.visible=false;PG.add(G_IDLE,G_FIRE);PG.scale.setScalar(.8);
function flameTex(){const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');x.translate(64,64);
  const g=x.createRadialGradient(0,0,2,0,0,60);g.addColorStop(0,'#fff');g.addColorStop(.25,'#ffe27a');g.addColorStop(.6,'#ff8a1e');g.addColorStop(1,'rgba(255,60,0,0)');x.fillStyle=g;
  x.beginPath();for(let i=0;i<16;i++){const a=i/16*Math.PI*2,r=i%2?26:60;x.lineTo(Math.cos(a)*r,Math.sin(a)*r)}x.closePath();x.fill();return c}
function texPlane(c,w,h,ro){const t=new THREE.CanvasTexture(c);t.magFilter=t.minFilter=THREE.NearestFilter;const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:t,transparent:true,fog:false,depthTest:false}));m.renderOrder=ro;return m}
const MF=texPlane(flameTex(),.28,.28,1310);MF.position.set(-.06,.32,.03);MF.visible=false;PG.add(MF);
const MG={visible:false,position:{y:0}}; // dummy for old reload anim refs

// --- Web Audio SFX + chainsaw ---
let AC_=null,SFXG=null,NB_=null;
function actx(){if(!AC_){AC_=new(window.AudioContext||window.webkitAudioContext)();SFXG=AC_.createGain();SFXG.gain.value=(typeof muted!=='undefined'&&muted)?0:.8;SFXG.connect(AC_.destination)}if(AC_.state==='suspended')AC_.resume();return AC_}
function noiseBuf(){const c=actx();if(!NB_){NB_=c.createBuffer(1,c.sampleRate,c.sampleRate);const d=NB_.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1}return NB_}
function sfxNoise(dur,fr,vol,type){try{const c=actx(),s=c.createBufferSource(),f=c.createBiquadFilter(),g=c.createGain();s.buffer=noiseBuf();f.type=type||'bandpass';f.frequency.value=fr;g.gain.setValueAtTime(vol,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+dur);s.connect(f);f.connect(g);g.connect(SFXG);s.start();s.stop(c.currentTime+dur)}catch(e){}}
function sfxTone(fr,dur,vol,type,end){try{const c=actx(),o=c.createOscillator(),g=c.createGain();o.type=type||'sine';o.frequency.setValueAtTime(fr,c.currentTime);o.frequency.exponentialRampToValueAtTime(Math.max(10,end||fr*.5),c.currentTime+dur);g.gain.setValueAtTime(vol,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+dur);o.connect(g);g.connect(SFXG);o.start();o.stop(c.currentTime+dur)}catch(e){}}
const sfxPull=()=>{sfxNoise(.28,2600,.28,'highpass');sfxTone(300,.2,.08,'square',120)};
const sfxSwing=()=>sfxNoise(.3,600,.3,'bandpass');
const sfxBite=h=>{if(h){sfxNoise(.35,900,.6,'lowpass');sfxTone(110,.35,.4,'sawtooth',50)}};
const sfxBreak=()=>{sfxNoise(.7,3000,.7,'bandpass');sfxTone(240,.8,.5,'sawtooth',30)};
const SAW={on:0};
function sawEngine(on){try{const c=actx();if(on&&!SAW.on){SAW.on=1;const o=c.createOscillator(),o2=c.createOscillator(),g=c.createGain(),f=c.createBiquadFilter(),n=c.createBufferSource(),ng=c.createGain();o.type='sawtooth';o2.type='square';o.frequency.value=55;o2.frequency.value=27.5;f.type='lowpass';f.frequency.value=700;n.buffer=noiseBuf();n.loop=true;ng.gain.value=.25;g.gain.value=0;o.connect(f);o2.connect(f);n.connect(ng);ng.connect(f);f.connect(g);g.connect(SFXG);o.start();o2.start();n.start();g.gain.setTargetAtTime(.22,c.currentTime,.1);Object.assign(SAW,{o,o2,g,f,n})}
 else if(!on&&SAW.on){SAW.on=0;const{o,o2,g,n}=SAW;g.gain.setTargetAtTime(0,c.currentTime,.05);setTimeout(()=>{try{o.stop();o2.stop();n.stop()}catch(e){}},300)}}catch(e){}}
function sawRev(k){if(!SAW.on)return;const t=AC_.currentTime;SAW.o.frequency.setTargetAtTime(55+k*60,t,.02);SAW.o2.frequency.setTargetAtTime(27.5+k*30,t,.02);SAW.f.frequency.setTargetAtTime(700+k*1400,t,.02)}
const mkTx=c=>{const t=new THREE.CanvasTexture(c);t.magFilter=t.minFilter=THREE.NearestFilter;return t};
function sawTex(fr){const c=document.createElement('canvas');c.width=160;c.height=96;const x=c.getContext('2d');let sd=7;const r=()=>(sd=sd*16807%2147483647)/2147483647;
 const R=(a,b,w,h,col)=>{x.fillStyle=col;x.fillRect(a,b,w,h)},P=(pts,col)=>{x.fillStyle=col;x.beginPath();pts.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]));x.fill()};
 x.save();x.translate(90,48);x.rotate(.45);R(-74,-7,76,14,'#4a4d50');R(-72,-4,70,8,'#222');for(let i=0;i<72;i+=6){R(-i-6+fr*3,-9,3,3,'#c9ccd0');R(-i-6+fr*3,6,3,3,'#c9ccd0')}R(-76,-5,4,10,'#4a4d50');x.restore();
 R(72,38,46,34,'#7d7f79');R(72,38,46,4,'#a5a7a0');R(72,68,46,4,'#55574f');R(78,50,12,8,'#8a4f2c');R(100,57,10,9,'#8a4f2c');R(104,32,8,6,'#a01c1c');R(94,50,14,14,'#5a5c58');R(98,54,6,6,'#2a2a2a');R(70,34,4,38,'#3a3a3a');R(112,42,18,6,'#2c2c2c');
 P([[116,58],[136,44],[160,66],[160,96],[132,96]],'#f0cfa4');P([[124,64],[140,52],[152,64],[134,78]],'#ece7da');P([[136,86],[152,70],[160,76],[160,96],[142,96]],'#ece7da');
 x.fillStyle='#f0cfa4';x.beginPath();x.arc(126,50,9,0,7);x.fill();R(118,46,16,4,'#ece7da');
 for(let i=0;i<30;i++)R(60+r()*100|0,30+r()*66|0,2+(r()*3|0),2+(r()*5|0),'#a3141a');
 return c}
function lhTex(){const c=document.createElement('canvas');c.width=80;c.height=96;const x=c.getContext('2d');let sd=3;const r=()=>(sd=sd*16807%2147483647)/2147483647;
 const P=(pts,col)=>{x.fillStyle=col;x.beginPath();pts.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]));x.fill()};
 P([[0,96],[0,62],[44,28],[70,38],[42,96]],'#f0cfa4');P([[12,62],[40,38],[56,52],[28,78]],'#ece7da');P([[6,90],[0,80],[0,96],[16,96]],'#ece7da');
 x.fillStyle='#f0cfa4';x.beginPath();x.arc(60,28,11,0,7);x.fill();x.fillStyle='#ece7da';x.fillRect(50,30,20,4);x.fillStyle='#b88';for(let i=0;i<3;i++)x.fillRect(52+i*6,18,1,8);
 x.fillStyle='#a3141a';for(let i=0;i<14;i++)x.fillRect(r()*70|0,20+r()*76|0,2+(r()*3|0),2+(r()*5|0));return c}
const SG=new THREE.Group();cam.add(SG);SG.visible=false;SG.position.set(.12,-.24,-.58);
const SAWT=[mkTx(sawTex(0)),mkTx(sawTex(1))];
const mkPl=(t,w,h,ro)=>{const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({map:t,transparent:true,fog:false,depthTest:false}));m.renderOrder=ro;return m};
const SAWP=mkPl(SAWT[0],1.1,.66,1400),LHP=mkPl(mkTx(lhTex()),.4,.48,1402);
const cordG=new THREE.BufferGeometry();cordG.setAttribute('position',new THREE.BufferAttribute(new Float32Array(6),3));
const CORD=new THREE.Line(cordG,new THREE.LineBasicMaterial({color:0xe8e0c8,depthTest:false,fog:false}));CORD.renderOrder=1403;CORD.frustumCulled=false;
SG.add(SAWP,LHP,CORD);
const SW={act:0,t:0,ready:0,n:-1,gt:0,ft:0,fr:0,side:0};
function sawFrame(dt,bob,dip){const T=(SW.t+=dt),G=-.114,H=-.02;let lx=0,ly=-.6,sh=0,cord=0;
 if(!SW.ready){
  if(T<.35){ly=-.6+.44*T/.35}
  else{const q=(T-.35)/.3,n=Math.floor(q);
   if(n<3){const f=q-n,a=f<.6?f/.6:1-(f-.6)/.4;lx=-.12*a;ly=-.16+.12*a;cord=1;sh=.004*a;if(n!==SW.n){SW.n=n;sfxPull();if(n<2)sfxTone(70,.15,.3,'sawtooth',35)}}
   else{SW.ready=1;SW.gt=0;sawEngine(1);sawRev(1);sfxTone(80,.4,.4,'sawtooth',160)}}}
 if(SW.ready){SW.gt+=dt;const g=Math.min(1,SW.gt/.3);lx=g*G;ly=-.16+(H+.16)*g;sh=.006;sawRev(atkT>0?1:(blockT>0?.4:0));SW.ft+=dt;if(SW.ft>.04){SW.ft=0;SW.fr^=1;SAWP.material.map=SAWT[SW.fr]}}
 let gp=[.12,-.24,-.58],gr=0;
 if(blockT>0){gp=[0,-.14,-.5];gr=.5}
 if(atkT>0&&SW.ready){const p=1-atkT/.45,s=Math.sin(p*Math.PI),d=SW.side?1:-1;gp=[.12+d*(.4-.8*p),-.24+.1*s,-.58-.14*s];gr=d*(-.6+1.2*p);sh=.012}
 const k=Math.min(1,dt*(atkT>0?30:14));
 SG.position.x+=(gp[0]-SG.position.x)*k+(rnd()-.5)*sh;SG.position.y+=(gp[1]+bob-dip-SG.position.y)*k+(rnd()-.5)*sh;SG.position.z+=(gp[2]-SG.position.z)*k;SG.rotation.z+=(gr-SG.rotation.z)*k;
 LHP.position.set(lx,ly,.01);
 if(cord){const p=cordG.attributes.position;p.setXYZ(0,.103,-.055,.005);p.setXYZ(1,lx+.1,ly+.1,.005);p.needsUpdate=true}CORD.visible=!!cord}
function sawHit(){const fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw);let hit=0;
 for(const e of npcs){if(e.dead||e.friendly||e.fin)continue;const dx=e.p.x-P.x,dz=e.p.z-P.z,d=Math.hypot(dx,dz);
  if(d<2.6&&(dx*fx+dz*fz)/d>.25){hit=1;addWound(e,'s',1.2+rnd()*.5);addWound(e,'k',1+rnd()*.5);blood(e.p.x,1.3,e.p.z,70,fx,fz);if(e.type==='enemy')e.hp=1;dmgE(e,fx,fz,.6);if(e.dead)gibs(e.p.x,1.3,e.p.z,fx,fz)}}
 sfxBite(hit);shake=.14;
 if(--inv.saw<=0){inv.saw=0;sawEngine(0);sfxBreak();toast('Бензопила сломалась!',1800);swapT=.3;pendW=allowed[0]}
 updAmmo()}

// --- state ---
const P={x:0,z:15,y:0,vy:0,hp:100,yaw:Math.PI,pitch:0};
let started=false,over=false,now=0,kills=0,atkT=0,hitDone=true,blockT=0,dashT=0,dashCd=0,dvx=0,dvz=0,inst,instI=0,instNext=0,bobT=0,weapon=0,ammo=12,reload=0,swapT=0,pendW=-1,swLatch=0,gcd=0,recoil=0,flashT=0;
let sc=0,smokeUntil=0,kick=0,smokeT=0,inv={ammo:0,knives:0,med:0,saw:0},items=[],projs=[],paused=false,fin=null,shake=0,parryT=0,hAcc=0,lvl=0,goal=0,tutStep=0,hits=0,parries=0,moved=0,turned=0,dashed=0,jumped=0,allowed=[0],nextLv=0;
const hold={atk:0,blk:0,jmp:0,dash:0,swap:0},key={};
const lines=['Эй, боец! Левый стик — идти.','Тяни правую часть — смотреть.','⚔ — удар ножом!','🛡 — блок. В момент удара = парирование!','РЫВОК слева, ▲ прыжок. Зачисти всех!'];
function reset(){npcs.forEach(n=>{scene.remove(n.g);n.el.remove()});npcs.length=0;
  decals.forEach(d=>scene.remove(d));decals.length=0;parts.forEach(d=>scene.remove(d));parts.length=0;
  Object.assign(P,{x:0,z:15,y:0,vy:0,hp:100,yaw:Math.PI,pitch:0});kills=0;instI=0;instNext=0;over=false;
  inst=mkNPC(3,12,0x3d4a34,true);
  [[-14,14],[14,14],[-16,-2],[14,-10],[4,-16],[-4,-16],[14,2]].forEach(a=>mkNPC(a[0],a[1],0x4a4a3a,false));
  $('over').style.display='none';weapon=0;ammo=12;reload=0;swapT=0;pendW=-1;setW();hud()}
function hud(){$('hpf').style.width=Math.max(0,P.hp)+'%';$('kills').textContent=(lvl?'Убито: '+kills+' / '+goal:'Обучение')}
function hurt(d){P.hp-=d;$('flash').style.opacity=.6;hud();if(P.hp<=0&&!over)nextLv=lvl;$('again').textContent='ЗАНОВО';end('ТЫ ПОГИБ')}
function end(t){over=true;$('ot').textContent=t;$('over').style.display='flex'}

// --- input ---
let mv={x:0,y:0};
const stick=$('stick'),knob=$('knob');let sid=null;
function sMove(e){const r=stick.getBoundingClientRect(),R0=r.width/2;let dx=e.clientX-(r.left+R0),dy=e.clientY-(r.top+R0);const l=Math.hypot(dx,dy),m=Math.min(1,l/R0);if(l>0){dx/=l;dy/=l}mv.x=dx*m;mv.y=-dy*m;knob.style.transform=`translate(${dx*m*R0*.6}px,${dy*m*R0*.6}px)`}
stick.addEventListener('pointerdown',e=>{sid=e.pointerId;stick.setPointerCapture(sid);sMove(e);e.preventDefault()});
stick.addEventListener('pointermove',e=>{if(e.pointerId===sid)sMove(e)});
const sEnd=e=>{if(e.pointerId===sid){sid=null;mv.x=mv.y=0;knob.style.transform=''}};
stick.addEventListener('pointerup',sEnd);stick.addEventListener('pointercancel',sEnd);
const look=$('look');let lid=null,lx=0,ly=0;
look.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'){look.requestPointerLock&&look.requestPointerLock();if(e.button===0)hold.atk=1;if(e.button===2)hold.blk=1;return}lid=e.pointerId;look.setPointerCapture(lid);lx=e.clientX;ly=e.clientY});
look.addEventListener('pointermove',e=>{if(e.pointerId===lid){P.yaw-=(e.clientX-lx)*.007*sens;turned+=Math.abs(e.clientX-lx)*.007*sens;P.pitch=Math.max(-1.2,Math.min(1.2,P.pitch-(e.clientY-ly)*.007*sens));lx=e.clientX;ly=e.clientY}});
look.addEventListener('pointerup',e=>{if(e.pointerType==='mouse'){if(e.button===0)hold.atk=0;if(e.button===2)hold.blk=0}if(e.pointerId===lid)lid=null});
look.addEventListener('pointercancel',()=>lid=null);
document.addEventListener('mousemove',e=>{if(document.pointerLockElement){P.yaw-=e.movementX*.0025*sens;turned+=Math.abs(e.movementX)*.0025*sens;P.pitch=Math.max(-1.2,Math.min(1.2,P.pitch-e.movementY*.0025*sens))}});
addEventListener('contextmenu',e=>e.preventDefault());
[['atk','atk'],['blk','blk'],['jmp','jmp'],['dash','dash'],['swap','swap']].forEach(([id,k])=>{const el=$(id);
  el.addEventListener('pointerdown',e=>{hold[k]=1;el.classList.add('on');e.preventDefault()});
  ['pointerup','pointercancel','pointerleave'].forEach(t=>el.addEventListener(t,()=>{hold[k]=0;el.classList.remove('on')}))});
addEventListener('keydown',e=>{key[e.code]=1;if(/^Digit[1-9]$/.test(e.code))slotUse(+e.code[5]-1);if(e.code==='Space')hold.jmp=1;if(e.code.startsWith('Shift'))hold.dash=1;if(e.code==='KeyQ'||e.code==='KeyE')hold.swap=1});
addEventListener('keyup',e=>{key[e.code]=0;if(e.code==='Space')hold.jmp=0;if(e.code.startsWith('Shift'))hold.dash=0;if(e.code==='KeyQ'||e.code==='KeyE')hold.swap=0});
const bgmURL='assets/music.mp3';
const bgm=(()=>{let ctx=null,gain=null,buf=null,src=null,want=false,vol=.55,mt=false;
 const apply=()=>{if(gain)gain.gain.value=mt?0:vol};
 function init(){if(ctx)return;const AC=window.AudioContext||window.webkitAudioContext;ctx=actx();gain=ctx.createGain();gain.connect(ctx.destination);apply();
  const done=b=>{buf=b;if(want)go()};fetch(bgmURL).then(r=>r.arrayBuffer()).then(a=>ctx.decodeAudioData(a,done,()=>{})).catch(()=>{})}
 function go(){if(!buf||src)return;src=ctx.createBufferSource();src.buffer=buf;src.loop=true;src.connect(gain);src.start(0)}
 return{get volume(){return vol},set volume(v){vol=v;apply()},get muted(){return mt},set muted(m){mt=m;apply()},
  play(){want=true;init();if(ctx.state==='suspended')ctx.resume();go();return Promise.resolve()},
  pause(){want=false;if(ctx&&ctx.state==='running')ctx.suspend()}}})();let muted=false;
$('mute').addEventListener('pointerdown',e=>{muted=!muted;bgm.muted=muted;if(SFXG)SFXG.gain.value=muted?0:.8;$('mute').textContent=muted?'🔇':'🔊';e.preventDefault()});
document.addEventListener('visibilitychange',()=>{if(document.hidden)bgm.pause();else if(started)bgm.play().catch(()=>{})});
function mSm(x,pts,fill){x.beginPath();const n=pts.length,md=(a,b)=>[(a[0]+b[0])/2,(a[1]+b[1])/2];const m0=md(pts[n-1],pts[0]);x.moveTo(m0[0],m0[1]);for(let i=0;i<n;i++){const p=pts[i],m=md(p,pts[(i+1)%n]);x.quadraticCurveTo(p[0],p[1],m[0],m[1])}x.closePath();x.fillStyle=fill;x.fill()}
function mLg(x,a,b,c,d,st){const g=x.createLinearGradient(a,b,c,d);st.forEach((s,i)=>g.addColorStop(i/(st.length-1),s));return g}
function mLn(x,pts,col,w){x.strokeStyle=col;x.lineWidth=w;x.lineCap='round';x.beginPath();pts.forEach((p,i)=>i?x.lineTo(p[0],p[1]):x.moveTo(p[0],p[1]));x.stroke()}
function mHero(x,X,Y,s,bl){x.save();x.translate(X,Y);x.scale(s,s);
  const pant=mLg(x,-50,0,50,0,['#a9d1ec','#6f9fc2','#4b7290']);
  mSm(x,[[-46,-178],[-4,-182],[-8,-92],[-14,-14],[-42,-12],[-40,-92]],pant);
  mSm(x,[[4,-182],[46,-178],[42,-92],[38,-14],[10,-12],[8,-92]],pant);
  mSm(x,[[-52,-14],[-12,-16],[-8,2],[-56,4]],'#cbc3b2');mSm(x,[[8,-16],[48,-14],[56,4],[4,2]],'#cbc3b2');
  mSm(x,[[-48,-190],[0,-186],[48,-190],[46,-166],[0,-162],[-46,-166]],'#d9d2c0');
  mSm(x,[[-58,-292],[0,-304],[58,-292],[50,-170],[0,-160],[-50,-170]],mLg(x,-56,0,56,0,['#c0c8de','#929bb6','#5f6784']));
  [[-22,-262,-8,-222],[12,-256,28,-208],[-34,-204,-12,-184],[-2,-282,4,-250]].forEach(a=>mLn(x,[[a[0],a[1]],[a[2],a[3]]],'rgba(60,66,96,.6)',3));
  // left arm raised fist
  mSm(x,[[-62,-294],[-44,-286],[-64,-214],[-96,-226]],'#8a94b0');
  mSm(x,[[-94,-224],[-64,-212],[-46,-262],[-72,-272]],'#d3bf9f');
  mSm(x,[[-84,-296],[-42,-296],[-34,-256],[-70,-244],[-90,-262]],'#dbc8a8');
  mLn(x,[[-76,-282],[-52,-288]],'rgba(90,70,50,.5)',2);mLn(x,[[-80,-270],[-46,-276]],'rgba(90,70,50,.5)',2);
  // right arm hanging with knife
  mSm(x,[[44,-292],[64,-284],[76,-208],[54,-198]],'#7e88a6');
  mSm(x,[[52,-204],[78,-208],[80,-150],[58,-146]],'#d3bf9f');
  mSm(x,[[54,-152],[86,-154],[88,-118],[58,-114]],'#dbc8a8');
  mLn(x,[[66,-122],[68,-56]],'#111',7);mLn(x,[[68,-56],[66,-30]],'#1c1c22',5);mLn(x,[[64,-120],[66,-60]],'#565a62',2);
  // head
  mSm(x,[[-15,-298],[15,-298],[17,-322],[-17,-322]],'#c9b494');
  mSm(x,[[-27,-352],[-22,-382],[0,-396],[24,-382],[29,-352],[21,-324],[0,-314],[-21,-324]],mLg(x,-28,0,30,0,['#e6d6b8','#cdb894','#a58f70']));
  mSm(x,[[-28,-368],[0,-378],[29,-368],[29,-357],[0,-366],[-28,-357]],'#93a5c6');
  mSm(x,[[28,-366],[44,-360],[40,-346],[30,-356]],'#7f91b2');
  x.fillStyle='rgba(30,20,20,.75)';[[-11,-347],[11,-347]].forEach(p=>{x.beginPath();x.ellipse(p[0],p[1],6,3.2,0,0,7);x.fill()});
  x.fillStyle='rgba(255,255,255,.7)';x.fillRect(-13,-348,2,1.5);x.fillRect(9,-348,2,1.5);
  mLn(x,[[-19,-354],[-4,-351]],'rgba(70,50,40,.7)',2.5);mLn(x,[[4,-351],[19,-354]],'rgba(70,50,40,.7)',2.5);
  mLn(x,[[0,-346],[-2,-334],[3,-333]],'rgba(110,80,60,.6)',2);mLn(x,[[-7,-326],[7,-326]],'rgba(80,40,40,.8)',2.5);
  if(bl){x.fillStyle='rgba(150,10,10,.8)';[[-30,-260,10],[20,-230,14],[-10,-190,9],[30,-140,12],[-24,-100,10],[60,-140,8],[-70,-240,9],[0,-350,4],[-14,-336,3]].forEach(a=>{x.beginPath();x.arc(a[0],a[1],a[2],0,7);x.fill()});mLn(x,[[66,-100],[68,-50]],'#a01010',4)}
  x.restore()}
function mGuard(x,X,Y,s,lie){x.save();x.translate(X,Y);
  if(lie){x.fillStyle='rgba(120,8,8,.85)';x.beginPath();x.ellipse(-150*s,4,190*s,26,0,0,7);x.fill();x.fillStyle='rgba(70,0,0,.7)';x.beginPath();x.ellipse(-120*s,6,120*s,14,0,0,7);x.fill();x.scale(s,s*.52);x.rotate(-Math.PI/2);x.translate(0,-5)}
  else x.scale(s,s);
  const un=mLg(x,-54,0,54,0,['#485570','#2f3a52','#1f2638']);
  mSm(x,[[-40,-178],[-4,-182],[-8,-92],[-14,-14],[-40,-12],[-38,-92]],'#252a36');mSm(x,[[4,-182],[40,-178],[40,-92],[36,-14],[12,-12],[8,-92]],'#252a36');
  mSm(x,[[-48,-14],[-12,-16],[-8,2],[-54,4]],'#0d0d10');mSm(x,[[8,-16],[46,-14],[54,4],[4,2]],'#0d0d10');
  mSm(x,[[-58,-292],[0,-304],[58,-292],[50,-170],[0,-160],[-50,-170]],un);
  mSm(x,[[-50,-184],[50,-184],[50,-166],[-50,-166]],'#0c0c10');x.fillStyle='#b8a040';x.fillRect(-7,-182,14,12);x.fillStyle='#16181e';x.fillRect(-46,-176,12,24);
  x.fillStyle='#d0b040';x.fillRect(18,-262,10,12);
  mSm(x,[[-62,-294],[-44,-286],[-58,-190],[-78,-194]],un);mSm(x,[[44,-286],[62,-294],[78,-194],[58,-190]],un);
  mSm(x,[[-80,-196],[-56,-190],[-56,-160],[-78,-160]],'#c6a58c');mSm(x,[[56,-190],[80,-196],[78,-160],[56,-160]],'#c6a58c');
  mLn(x,[[68,-156],[74,-110]],'#111',10);
  mSm(x,[[-14,-298],[14,-298],[16,-320],[-16,-320]],'#b48f78');
  mSm(x,[[-24,-350],[-20,-376],[0,-388],[21,-376],[25,-350],[18,-324],[0,-316],[-18,-324]],mLg(x,-24,0,26,0,['#d6b8a0','#bb987e','#8f715c']));
  mSm(x,[[-30,-372],[0,-396],[30,-372],[32,-362],[0,-372],[-32,-362]],'#14161c');mSm(x,[[-34,-364],[34,-364],[30,-356],[-30,-356]],'#0b0c10');x.fillStyle='#c8b060';x.fillRect(-4,-388,8,6);
  x.fillStyle='rgba(20,15,15,.85)';[[-9,-345],[9,-345]].forEach(p=>{x.beginPath();x.ellipse(p[0],p[1],5,2.6,0,0,7);x.fill()});mLn(x,[[-6,-328],[6,-328]],'rgba(70,30,30,.8)',2.5);
  if(lie){x.fillStyle='rgba(150,10,10,.85)';[[-8,-250,12],[16,-214,10],[0,-330,6]].forEach(a=>{x.beginPath();x.arc(a[0],a[1],a[2],0,7);x.fill()})}
  x.restore()}
function mScene(st){const c=document.createElement('canvas');c.width=960;c.height=540;const x=c.getContext('2d');
  const VX=610,VY=262,FW=46,FH=74,NL=-150,NR=1370,NT=-200,NB=720,fl=VX-FW,fr=VX+FW,ft=VY-FH,fb=VY+FH,lp=(a,b,t)=>a+(b-a)*t,S=d=>d/(d+1);
  const pl=(p,f)=>{x.beginPath();p.forEach((q,i)=>i?x.lineTo(q[0],q[1]):x.moveTo(q[0],q[1]));x.closePath();x.fillStyle=f;x.fill()};
  const Lw=(s,f)=>[lp(NL,fl,s),lp(lp(NT,ft,s),lp(NB,fb,s),f)],Rw=(s,f)=>[lp(NR,fr,s),lp(lp(NT,ft,s),lp(NB,fb,s),f)];
  pl([[NL,NT],[fl,ft],[fl,fb],[NL,NB]],mLg(x,NL,0,fl,0,['#3a3234','#5a5256']));
  pl([[NR,NT],[fr,ft],[fr,fb],[NR,NB]],mLg(x,NR,0,fr,0,['#312b2e','#544e54']));
  pl([[NL,NT],[NR,NT],[fr,ft],[fl,ft]],mLg(x,0,NT,0,ft,['#221f24','#45434c']));
  pl([[NL,NB],[NR,NB],[fr,fb],[fl,fb]],mLg(x,0,NB,0,fb,['#22232a','#4e525f']));
  pl([Lw(0,.62),Lw(1,.62),Lw(1,1),Lw(0,1)],'rgba(40,58,52,.75)');pl([Rw(0,.62),Rw(1,.62),Rw(1,1),Rw(0,1)],'rgba(40,58,52,.7)');
  [.3,.7,1.2,2,3.5].forEach(d=>{const s=S(d);mLn(x,[Lw(s,0),Lw(s,1)],'rgba(15,10,10,.6)',2);mLn(x,[Rw(s,0),Rw(s,1)],'rgba(15,10,10,.6)',2);mLn(x,[[lp(lp(NL,fl,s),lp(NR,fr,s),0),lp(NT,ft,s)],[lp(lp(NL,fl,s),lp(NR,fr,s),1),lp(NT,ft,s)]],'rgba(15,10,10,.6)',2)});
  const door=(W,d0,d1,red)=>{const a=S(d0),b=S(d1);pl([W(a,.12),W(b,.12),W(b,1),W(a,1)],'#161416');mLn(x,[W(a,.12),W(b,.12),W(b,1),W(a,1),W(a,.12)],'#6a6064',3);
    pl([W(lp(a,b,.3),.2),W(lp(a,b,.7),.2),W(lp(a,b,.7),.42),W(lp(a,b,.3),.42)],red?'#4a2224':'#2a2c34');for(let i=0;i<=4;i++){const t=lp(a,b,.3+.1*i);mLn(x,[W(t,.2),W(t,.42)],'#9a9ca6',2)}};
  door(Lw,.45,.85,0);door(Lw,1.5,2,0);door(Rw,.7,1.1,1);door(Rw,2,2.6,1);
  for(let i=0;i<40;i++){const s=Math.random(),f=Math.random()*.6;const p=Math.random()<.5?Lw(s,f):Rw(s,f);x.fillStyle='rgba(20,10,10,.25)';x.fillRect(p[0],p[1],2+Math.random()*3,10+Math.random()*30)}
  const tb=[lp(lp(NL,fl,S(1.6)),lp(NR,fr,S(1.6)),.4),lp(NT,ft,S(1.6))],tb2=[lp(lp(NL,fl,S(1.6)),lp(NR,fr,S(1.6)),.6),tb[1]];mLn(x,[tb,tb2],'#e6ecff',6);
  // sign
  x.fillStyle='#c5bfb3';x.fillRect(405,58,420,92);x.strokeStyle='#221';x.lineWidth=3;x.strokeRect(405,58,420,92);mLn(x,[[430,58],[440,0]],'#333',3);mLn(x,[[800,58],[790,0]],'#333',3);
  x.fillStyle='#222';x.textAlign='center';x.font='bold 34px Oswald,Arial Narrow,sans-serif';x.fillText('ПСИХИАТРИЧЕСКАЯ',650,100);x.fillText('БОЛЬНИЦА',660,136);x.font='bold 56px serif';x.fillText('Ψ',450,112);
  x.fillStyle='rgba(120,10,10,.7)';x.beginPath();x.arc(780,140,10,0,7);x.fill();x.fillRect(776,140,4,24);
  // writings
  x.save();x.translate(392,292);x.rotate(-.06);x.fillStyle='#a01212';x.font='bold 30px Oswald,Arial Narrow,sans-serif';x.fillText('ТЫ',0,0);x.fillText('НЕ ОДИН',10,30);mLn(x,[[-5,36],[-5,66]],'#a01212',2);x.restore();
  x.save();x.translate(808,96);x.rotate(-.36);x.fillStyle='#a01212';x.font='bold 30px Oswald,Arial Narrow,sans-serif';x.fillText('ЗДЕСЬ',0,0);x.fillText('НЕ ТОЛЬКО',0,32);x.fillText('ЛЕЧАТ…',0,64);x.restore();
  // floor stuff
  const g=x.createLinearGradient(VX,fb,VX,540);g.addColorStop(0,'rgba(220,225,245,.55)');g.addColorStop(1,'rgba(220,225,245,0)');x.fillStyle=g;x.beginPath();x.moveTo(VX-16,fb);x.lineTo(VX+16,fb);x.lineTo(VX+80,540);x.lineTo(VX-80,540);x.fill();
  [[700,430,90,16],[560,395,60,10],[830,470,110,18]].forEach(a=>{x.fillStyle='rgba(110,20,24,.5)';x.beginPath();x.ellipse(a[0],a[1],a[2],a[3],0,0,7);x.fill()});
  pl([[720,470],[770,462],[780,480],[725,488]],'#d8d4cc');pl([[760,490],[810,482],[818,498],[765,506]],'#cfcac0');x.fillStyle='rgba(140,10,10,.7)';x.beginPath();x.ellipse(770,486,26,8,0,0,7);x.fill();
  // gurney
  pl([[350,330],[455,326],[470,346],[362,352]],'#3a2a2c');mLn(x,[[360,352],[352,392]],'#555',4);mLn(x,[[462,346],[458,388]],'#555',4);mLn(x,[[350,392],[470,388]],'#444',3);x.fillStyle='#666';[[352,394],[460,390]].forEach(a=>{x.beginPath();x.arc(a[0],a[1],7,0,7);x.fill()});
  // wheelchair
  x.strokeStyle='#4a2a2c';x.lineWidth=7;x.beginPath();x.arc(890,440,74,0,7);x.stroke();x.lineWidth=2;for(let i=0;i<10;i++){x.beginPath();x.moveTo(890,440);x.lineTo(890+Math.cos(i*.63)*74,440+Math.sin(i*.63)*74);x.stroke()}mLn(x,[[830,330],[860,300],[930,300]],'#3a2a2c',7);mLn(x,[[860,300],[870,430]],'#3a2a2c',7);
  // far door
  x.fillStyle='#e4e9f6';x.fillRect(fl+6,ft+6,FW*2-12,FH*2-12);mLn(x,[[VX,ft+6],[VX,fb-6]],'#7a7f92',2);mLn(x,[[fl+6,VY-10],[fr-6,VY-10]],'#7a7f92',2);
  const gg=x.createRadialGradient(VX,VY,4,VX,VY,120);gg.addColorStop(0,'rgba(230,236,255,.7)');gg.addColorStop(1,'rgba(230,236,255,0)');x.fillStyle=gg;x.fillRect(VX-130,VY-130,260,260);
  if(st===0){mHero(x,655,436,.8,0);mGuard(x,580,500,.86,0)}
  else{mGuard(x,700,492,.9,1);mHero(x,560,458,.9,1)}
  return c}

let sens=1,menuFromGame=false;
try{const v=localStorage.getItem('bk_vol'),q=localStorage.getItem('bk_sens');if(v!==null)bgm.volume=+v;if(q!==null)sens=+q}catch(e){}
function stopIntro(){}
function menuShow(){$('start').style.display='block';$('mpanel').style.display='none';$('mui').style.display='flex';$('mmsg').textContent='';
  let sv=0;try{sv=+localStorage.getItem('bk_lvl')||0}catch(e){}$('mcont').classList.toggle('dim',!(menuFromGame||sv>0));}
$('start').addEventListener('pointerdown',()=>{bgm.play().catch(()=>{})},{once:true});
$('mmenu').addEventListener('pointerdown',e=>{e.preventDefault();menuFromGame=started&&!over;if(menuFromGame)paused=true;menuShow()});
$('mcont').onclick=()=>{if(menuFromGame){stopIntro();$('start').style.display='none';paused=false;menuFromGame=false;return}
  let sv=0;try{sv=+localStorage.getItem('bk_lvl')||0}catch(e){}
  if(sv>0){stopIntro();$('start').style.display='none';bgm.play().catch(()=>{});started=true;startLevel(sv)}else $('mmsg').textContent='Нет сохранения. Начни новую игру.'};
$('mset').onclick=()=>{$('mui').style.display='none';$('mpanel').style.display='block';$('svol').value=Math.round(bgm.volume*100);$('ssens').value=Math.round(sens*100)};
$('sback').onclick=()=>{$('mpanel').style.display='none';$('mui').style.display='flex'};
$('svol').oninput=e=>{bgm.volume=e.target.value/100;try{localStorage.setItem('bk_vol',bgm.volume)}catch(x){}};
$('ssens').oninput=e=>{sens=e.target.value/100;try{localStorage.setItem('bk_sens',sens)}catch(x){}};
$('mexit').onclick=()=>{try{window.close()}catch(e){}$('mmsg').textContent='Можно закрыть вкладку. Спасибо за игру!'};
menuShow();
$('go').onclick=()=>{menuFromGame=false;stopIntro();bgm.play().catch(()=>{});$('start').style.display='none';started=true;startLevel(0);
  try{document.documentElement.requestFullscreen()}catch(e){}try{screen.orientation.lock('landscape').catch(()=>{})}catch(e){}};
$('again').onclick=()=>startLevel(nextLv);

// --- combat ---
function doHit(){const fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw);
  for(const e of npcs){if(e.dead||e.friendly||e.fin)continue;const dx=e.p.x-P.x,dz=e.p.z-P.z,d=Math.hypot(dx,dz);
    if(d<2.5&&(dx*fx+dz*fz)/d>.3){
      const ay=1.6+P.y+Math.tan(P.pitch)*d,z=ay>1.72?0:(ay>1.45?1:2);
      if(e.type==='enemy'&&(z<2||e.hp<=1)){startFin(e,z);return}
      addWound(e,'k',1+rnd()*.5);dmgE(e,fx,fz,.8);return}}}

function fistHit(){const fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw);
  for(const e of npcs){if(e.dead||e.friendly||e.fin)continue;const dx=e.p.x-P.x,dz=e.p.z-P.z,d=Math.hypot(dx,dz);
    if(d<2.3&&(dx*fx+dz*fz)/d>.25){
      const ay=1.6+P.y+Math.tan(P.pitch)*d,isHead=ay>1.55;
      if(e.type!=='enemy'){dmgE(e,fx,fz,.3);return}
      e.aggro=1;if(!e.fH)e.fH=0;if(!e.fB)e.fB=0;
      if(isHead){e.fH++;addWound(e,'b',1.65);blood(e.p.x,1.7,e.p.z,18,-fx,-fz);e.flash=.12;e.stun=.45;
        say(e,e.fH>=4?'Аааа!':'Аргх!',900);
        if(e.fH>=4){e.hp=1;dmgE(e,fx,fz,0)}else shake=.06}
      else{e.fB++;addWound(e,'b',.9+rnd()*.4);blood(e.p.x,1.1,e.p.z,14,-fx,-fz);e.flash=.1;e.stun=.35;
        say(e,e.fB>=6?'Ааргх!':'Уф!',700);
        if(e.fB>=6){e.hp=1;dmgE(e,fx,fz,.5)}else shake=.04}
      return}}}
function startFin(e,z){addWound(e,'s',[1.75,1.55,1.15][z]);fin={e,z,t:0,a:0,b:0,g:0};e.fin=1;e.fz=z;e.gush=1;e.wy=[1.75,1.55,1.15][z];e.stun=99;e.wind=0;e.par=0;atkT=0;P.yaw=Math.atan2(P.x-e.p.x,P.z-e.p.z);P.pitch=0;
  toast(['Удар в голову!','Удар в шею!','Добивание в корпус!'][z],1300)}
function strike(e){e.sk=.2;const d=Math.hypot(e.p.x-P.x,e.p.z-P.z);if(d>2.2)return;
  if(blockT>0){if(blockT<.9){e.stun=1.8;e.par=1;e.sk=0;shake=.12;parryT=.3;parries++;say(e,'Блок!',900);blood(P.x-Math.sin(P.yaw)*1.2,1.3,P.z-Math.cos(P.yaw)*1.2,8,0,0)}}
  else hurt(e.type==='trainer'?4:12)}

function setW(){const isGun=weapon===1,isFist=weapon===3,isMelee=weapon===0||weapon===2;RH.visible=isMelee;LH.visible=isMelee;F_RH.visible=isFist;F_LH.visible=isFist;PG.visible=isGun;SG.visible=weapon===4;if(weapon===4){if(!SW.act){SW.act=1;SW.t=0;SW.ready=0;SW.n=-1;SW.gt=0}}else{SW.act=0;SW.ready=0;sawEngine(0)}$('swap').textContent=['🔪','🔫','🗡','👊','⚙'][nextW()];$('atk').textContent=['⚔','💥','🗡','👊','⚙'][weapon];$('blk').textContent=isGun?'↻':'🛡';updAmmo()}
function updAmmo(){$('ammo').textContent=weapon===1?(reload>0?'ПЕРЕЗАРЯДКА...':'Патроны: '+ammo+' / 12  (запас '+inv.ammo+')'):weapon===2?'Метательные ножи: '+inv.knives:weapon===3?'Кулаки':weapon===4?'Бензопила: прочность '+inv.saw+' / 20':'Нож';hb()}
function startReload(){if(reload>0||ammo>=12)return;if(inv.ammo<=0){toast('Нет патронов в запасе',900);return}reload=1.2;updAmmo()}
function dmgE(e,fx,fz,k){if(e.type==='enemy'&&!e.fin&&!e.dead&&rnd()<.2){e.aggro=1;e.stun=.35;e.wind=0;e.flash=.08;say(e,'Блок!',700);sfxNoise(.15,2500,.5,'bandpass');return}e.aggro=1;e.par=0;e.hp--;if(e.type!=='enemy'){e.hp=3;if(e.type==='dummy')hits++}e.stun=.5;e.wind=0;e.flash=.1;blood(e.p.x,1.1,e.p.z,e.hp<=0?60:22,fx,fz);decal(e.p.x+fx*.5,e.p.z+fz*.5);e.p.x+=fx*k;e.p.z+=fz*k;collide(e.p,.4);
  if(e.hp<=0){e.dead=true;e.fs=rnd()<.5?-1:1;e.dt=0;kills++;hud();e.el.style.display='none';decal(e.p.x,e.p.z);decal(e.p.x+.4,e.p.z-.3);chKill(e)}else say(e,'Ааргх!',800)}
function rayWall(ox,oz,dx,dz){let best=1e9;for(const w of W){let t0=0,t1=1e9,ok=1;
  for(const [o,d,a,b] of [[ox,dx,w.a,w.b],[oz,dz,w.c,w.d]]){if(Math.abs(d)<1e-6){if(o<a||o>b)ok=0}else{let s1=(a-o)/d,s2=(b-o)/d;if(s1>s2){const q=s1;s1=s2;s2=q}t0=Math.max(t0,s1);t1=Math.min(t1,s2)}}
  if(ok&&t0<=t1&&t1>0)best=Math.min(best,t0)}return best}
function pistolHit(e,y){const fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw),z=y>1.62?0:(y>1.45?1:2);
  if(e.type!=='enemy'){dmgE(e,fx,fz,.3);return}
  e.aggro=1;
  if(z===0){e.wy=1.65;e.gush=1;e.suffer=0;e.hp=1;e.nohead=1;gibs(e.p.x,1.75,e.p.z,fx,fz);blood(e.p.x,1.75,e.p.z,130,-fx*1.3,-fz*1.3);blood(e.p.x,1.75,e.p.z,60,fx*2,fz*2);shake=.22;$('flash').style.opacity=.3;dmgE(e,fx,fz,0);return}
  if(z===1){addWound(e,'b',1.55);if(!(e.suffer>0))e.suffer=3;e.stun=0;e.wind=0;e.flash=.1;blood(e.p.x,1.55,e.p.z,30,-fx,-fz);say(e,'Аргх...',1500);return}
  e.body=(e.body||0)+1;e.flash=.1;addWound(e,'b',Math.min(1.4,Math.max(.6,y)));
  if(e.body>=3){e.wy=.5+rnd()*.9;e.gush=1;e.suffer=0;e.hp=1;blood(e.p.x,e.wy,e.p.z,45,-fx,-fz);dmgE(e,fx,fz,0)}
  else{e.stun=.5;e.wind=0;blood(e.p.x,.5+rnd()*.9,e.p.z,20,-fx,-fz);decal(e.p.x,e.p.z);say(e,'Ааргх!',800)}}
function shoot(){ammo--;gcd=.32;recoil=1;kick=.035;sc++;smokeUntil=now+6000;spawnShell();if(sc>=7)puff(1);flashT=.07;MF.rotation.z=rnd()*6.28;MF.scale.setScalar(.8+rnd()*.6);updAmmo();
  const cp=Math.cos(P.pitch),dx=-Math.sin(P.yaw)*cp,dy=Math.sin(P.pitch),dz=-Math.cos(P.yaw)*cp;
  const ox=P.x,oy=1.6+P.y,oz=P.z,hl=Math.hypot(dx,dz)||1e-6;let best=null,bt=rayWall(ox,oz,dx,dz),hy=0;
  for(const e of npcs){if(e.dead||e.friendly)continue;const vx=e.p.x-ox,vz=e.p.z-oz,t=(vx*dx+vz*dz)/(hl*hl);if(t<=0||t>=bt)continue;
    const lat=Math.abs(vx*dz-vz*dx)/hl,y=oy+dy*t;if(lat<.36&&y>.1&&y<1.95){best=e;bt=t;hy=y}}
  if(best)pistolHit(best,hy);
  if(ammo<=0)startReload()}
const LV=[0,{n:5,w:[3],t:'Глава 1: Побег'},{n:5,w:[3,0],t:'Глава 2: Такие же, как ты'},{n:6,w:[0,1,2,3,4],t:'Бонус: всё оружие'}];
const IV=[{ammo:0,knives:0,med:0,saw:0},{ammo:0,knives:0,med:0,saw:0},{ammo:0,knives:0,med:1,saw:0},{ammo:24,knives:3,med:1,saw:0}];
const SP=[[0,10],[2,3],[-2,-4],[8,-8],[0,-9],[8,0]];

// ===== ГЛАВЫ 1-2 =====
let chW=[],chKey=null,chDoor=null,chK=0,chExit=0;
function chWall(x,z,w,d,col){const o={a:x-w/2,b:x+w/2,c:z-d/2,d:z+d/2};W.push(o);const m=new THREE.Mesh(new THREE.BoxGeometry(w,4,d),new THREE.MeshBasicMaterial({color:col}));m.position.set(x,2,z);scene.add(m);const r={o,m};chW.push(r);return r}
function chRm(r){scene.remove(r.m);const i=W.indexOf(r.o);if(i>=0)W.splice(i,1)}
function chClear(){chW.forEach(chRm);chW.length=0;if(chKey){scene.remove(chKey);chKey=null}chDoor=null;chK=0;chExit=0}
function chMood(d){const c=d?0x0a0706:0x8c7d58;scene.background.set(c);scene.fog.color.set(c);scene.fog.near=d?2:12;scene.fog.far=d?22:42}
function chKeyMk(x,z){const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');g.font='44px serif';g.textAlign='center';g.fillText('🗝',32,46);const s=new THREE.Sprite(new THREE.SpriteMaterial({map:mkTx(c)}));s.position.set(x,.7,z);scene.add(s);return s}
function chUnlock(w,msg){if(!allowed.includes(w))allowed.push(w);$('swap').style.display='flex';updAmmo();toast(msg,4500)}
function chBuild(n){
 if(n===1){chDoor=chWall(0,-12.5,8.6,1,0x55353a);SP.slice(0,5).forEach(a=>mkNPC(a[0],a[1],0,false,'enemy'));
  toast('Сбой системы: двери открыты. Выйди из камеры и убей охрану',5500)}
 else{SP.slice(0,4).forEach(a=>mkNPC(a[0],a[1],0x4a4a3a,false,'enemy'));
  const g=mkNPC(SP[4][0],SP[4][1],0,false,'enemy');g.hp=6;g.guard=1;
  toast('Такие же пациенты, как ты. Убей их и охранника',5500)}}
function chKill(e){
 if(lvl===1){if(kills===1)chUnlock(0,'Взял нож охранника. Кнопка смены оружия');
  if(kills>=goal){chKey=chKeyMk(e.p.x,e.p.z);toast('Охрана мертва. Возьми ключ',4500)}}
 else if(lvl===2){if(e.guard){inv.ammo+=12;chUnlock(1,'Взял пистолет охранника (+12 патронов)')}
  else if(!chK){chK=1;inv.knives+=3;chUnlock(2,'Нашёл метательные ножи (3)')}
  if(kills>=goal)setTimeout(levelDone,2800)}
 else if(kills>=goal)setTimeout(levelDone,2800)}
function chTick(t){CAMS.forEach(c=>{c.g.rotation.y=c.ry+Math.sin(t/1500+c.ph)*.5;c.led.visible=((t/500)|0)%2===0});
 if(!started||over||paused||lvl!==1)return;
 if(chKey&&Math.hypot(P.x-chKey.position.x,P.z-chKey.position.z)<1.8){scene.remove(chKey);chKey=null;if(chDoor){chRm(chDoor);chDoor=null}toast('Дверь открыта! Иди вперёд',4500)}
 if(!chDoor&&!chExit&&kills>=goal&&P.z<-15){chExit=1;levelDone()}}
function startLevel(n){npcs.forEach(k=>{scene.remove(k.g);k.el.remove()});npcs.length=0;items.forEach(i=>scene.remove(i.sp));items.length=0;projs.forEach(p=>scene.remove(p.m));projs.length=0;shells.forEach(k=>scene.remove(k.m));shells.length=0;puffs.forEach(k=>scene.remove(k.sp));puffs.length=0;sc=0;paused=false;$('bag').style.display='none';
  decals.forEach(d=>scene.remove(d));decals.length=0;parts.forEach(d=>scene.remove(d));parts.length=0;
  lvl=n;kills=0;chClear();chMood(1);over=false;Object.assign(P,{x:n?-8:0,z:n?16:17,y:0,vy:0,hp:100,yaw:n?-Math.PI/2:0,pitch:0});atkT=0;blockT=0;
  tutStep=0;hits=0;parries=0;moved=0;turned=0;dashed=0;jumped=0;instNext=0;
  if(n===0){goal=0;allowed=[0];inst=mkNPC(2,9,1,true,'inst');mkNPC(-2,3,2,false,'dummy');mkNPC(2,-4,0,false,'trainer')}
  else{inst=null;goal=LV[n].n;allowed=LV[n].w.slice();if(n<3)chBuild(n);else{SP.slice(0,goal).forEach(a=>mkNPC(a[0],a[1],0,false,'enemy'));toast(LV[n].t+'. Подбирай патроны, ножи, аптечки, бензопилу',4500)}}
  weapon=allowed[0];inv=Object.assign({},IV[n]);if(n===3)spawnItems();ammo=12;reload=0;swapT=0;pendW=-1;$('swap').style.display=allowed.length>1?'flex':'none';
  $('over').style.display='none';setW();hud()}
function showNext(n){nextLv=n>3?0:n;try{localStorage.setItem('bk_lvl',n>3?0:n)}catch(e){}$('again').textContent=n>3?'СНОВА':'ДАЛЬШЕ';end(n>3?'ПОБЕДА! Все уровни пройдены':LV[n].t)}
function levelDone(){showNext(lvl+1)}
const IT={};
function itemTex(t){if(IT[t])return IT[t];const c=document.createElement('canvas');c.width=c.height=32;const x=c.getContext('2d');x.lineWidth=2;x.strokeStyle='#000';
  if(t==='ammo'){x.fillStyle='#c8a23a';x.fillRect(4,12,24,16);x.strokeRect(4,12,24,16);for(let i=0;i<4;i++){x.fillStyle='#f0d060';x.fillRect(7+i*6,4,4,10);x.strokeRect(7+i*6,4,4,10);x.fillStyle='#8a5a20';x.fillRect(7+i*6,4,4,3)}}
  else if(t==='med'){x.fillStyle='#f4f4f0';x.fillRect(3,7,26,20);x.strokeRect(3,7,26,20);x.fillStyle='#d81818';x.fillRect(13,10,6,14);x.fillRect(9,14,14,6);x.strokeRect(11,3,10,4)}
  else if(t==='saw'){x.fillStyle='#888';x.fillRect(12,12,16,12);x.strokeRect(12,12,16,12);x.fillStyle='#c33';x.fillRect(20,8,6,4);x.fillStyle='#ccc';x.fillRect(1,15,12,5);x.strokeRect(1,15,12,5);x.fillStyle='#222';x.fillRect(24,24,6,4)}
  else{x.translate(16,16);x.rotate(-.7);x.fillStyle='#cfd4d8';x.beginPath();x.moveTo(-14,-3);x.lineTo(6,-3);x.lineTo(13,0);x.lineTo(6,3);x.lineTo(-14,3);x.closePath();x.fill();x.stroke();x.fillStyle='#222';x.fillRect(-15,-4,8,8)}
  const q=new THREE.CanvasTexture(c);q.magFilter=q.minFilter=THREE.NearestFilter;return IT[t]=q}
function spawnItem(t,x,z,n){const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:itemTex(t)}));sp.scale.set(.6,.6,1);sp.position.set(x,.45,z);scene.add(sp);items.push({sp,type:t,x,z,n:n||1})}
function spotOk(x,z){for(const w of W)if(x>w.a-1&&x<w.b+1&&z>w.c-1&&z<w.d+1)return false;return Math.hypot(x,z-15)>3}
function spawnItems(){const put=(t,k,n)=>{for(let i=0;i<k;i++){let x,z,tr=0;do{x=(rnd()-.5)*36;z=(rnd()-.5)*36;tr++}while(!spotOk(x,z)&&tr<80);spawnItem(t,x,z,n)}};
  put('med',2);if(allowed.includes(1))put('ammo',4);if(allowed.includes(2))put('knife',3,3);if(allowed.includes(4))put('saw',1)}
function pick(it){if(it.type==='ammo'){inv.ammo+=12;toast('+12 патронов',900)}else if(it.type==='med'){inv.med=Math.min(5,inv.med+1);toast('+1 аптечка',900)}else if(it.type==='saw'){inv.saw=20;toast('Бензопила! Прочность: 20 ударов',2200)}else{inv.knives=Math.min(9,inv.knives+it.n);toast('+'+it.n+' метательных ножа',900)}updAmmo()}
function nextW(){const l=allowed.filter(w=>(w!==2||inv.knives>0)&&(w!==4||inv.saw>0));return l[(l.indexOf(weapon)+1)%l.length]}
function equip(w){if(fin||swapT>0||reload>0||w===weapon)return;if(!allowed.includes(w)){toast('Недоступно на этом уровне',1000);return}if(w===2&&inv.knives<=0){toast('Нет метательных ножей',1000);return}if(w===4&&inv.saw<=0){toast('Нет бензопилы',1000);return}swapT=.3;pendW=w}
function useMed(){if(inv.med<=0){toast('Нет аптечек',900);return}if(P.hp>=100){toast('Здоровье полное',900);return}inv.med--;P.hp=Math.min(100,P.hp+40);hud();toast('+40 здоровья',900);updAmmo()}
function slotUse(i){if(!started||over||paused)return;if(i<4)equip(i);else if(i===4){if(weapon===1)startReload();else toast('Патроны в запасе: '+inv.ammo,900)}else if(i===5)useMed();else if(i===6)equip(4)}
function throwKnife(){inv.knives--;const cp=Math.cos(P.pitch),d=new THREE.Vector3(-Math.sin(P.yaw)*cp,Math.sin(P.pitch),-Math.cos(P.yaw)*cp);
  const m=new THREE.Mesh(new THREE.BoxGeometry(.05,.02,.3),new THREE.MeshBasicMaterial({color:0xcfd4d8}));m.position.set(P.x+d.x*.5,1.5+P.y+d.y*.5,P.z+d.z*.5);scene.add(m);
  projs.push({m,v:d.clone().multiplyScalar(24),l:3,pv:m.position.clone()});updAmmo();
  if(inv.knives<=0){swapT=.3;pendW=allowed.includes(0)?0:1}}
function knifeHit(e,y){const fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw);e.aggro=1;
  if(e.type!=='enemy'){dmgE(e,fx,fz,.3);return}
  if(y>1.62){addWound(e,'s',y);e.wy=1.7;e.gush=1;e.suffer=0;e.hp=1;dmgE(e,fx,fz,0);return}
  addWound(e,'k',Math.min(1.5,Math.max(.6,y)));dmgE(e,fx,fz,.3);if(!e.dead)dmgE(e,fx,fz,0)}
let hbSig='';let fistSide=0;const HB=$('hotbar');
function hb(){const c=[['🔪',''],['🔫',ammo+'/'+inv.ammo],['🗡',inv.knives],['👊',''],['🔶',inv.ammo],['✚',inv.med],['🪚',inv.saw||'']];const sig=c.join('|')+weapon+allowed;if(sig===hbSig)return;hbSig=sig;
  let h='';for(let i=0;i<9;i++){const a=c[i];h+='<div class="slot'+((i===weapon&&i<4)||(i===6&&weapon===4)?' sel':'')+(a&&(i===6?(allowed.includes(4)&&inv.saw>0):(i>3||allowed.includes(i)))?'':' off')+'" data-i="'+i+'"><i>'+(i+1)+'</i>'+(a?a[0]:'')+'<small>'+(a?a[1]:'')+'</small></div>'}
  HB.innerHTML=h+'<div class="slot" id="bagb">🎒</div>'}
HB.addEventListener('pointerdown',e=>{const t=e.target.closest('.slot');if(!t)return;e.preventDefault();if(t.id==='bagb'){if(started&&!over){paused=true;bagRender();$('bag').style.display='flex'}}else slotUse(+t.dataset.i)});
function bagRender(){const R=(ic,nm,info,btn,fn)=>'<div class="row"><b>'+ic+'</b><span>'+nm+' <small style="opacity:.8">'+info+'</small></span>'+(btn?'<button onclick="bagDo(\''+fn+'\')">'+btn+'</button>':'')+'</div>';
  $('bagp').innerHTML='<h1 style="font-size:5vh;margin:0 0 1vh">🎒 РЮКЗАК</h1>'+R('🔪','Боевой нож','',allowed.includes(0)?'Взять':'','e0')+R('🔫','Пистолет','магазин '+ammo+'/12',allowed.includes(1)?'Взять':'','e1')+R('🗡','Метательные ножи','×'+inv.knives,allowed.includes(2)?'Взять':'','e2')+R('👊','Кулаки','удар в голову ×4 / тело ×6',allowed.includes(3)?'Взять':'','e3')+R('🪚','Бензопила','прочность '+inv.saw+' / 20',allowed.includes(4)&&inv.saw>0?'Взять':'','e4')+R('🔶','Патроны в запасе','×'+inv.ammo,weapon===1?'Перезарядить':'','rl')+R('✚','Аптечки','×'+inv.med+' (+40 HP)',inv.med?'Использовать':'','med')}
function bagDo(a){if(a==='med'){useMed();bagRender();return}closeBag();if(a==='rl')startReload();else equip(+a[1])}
function closeBag(){paused=false;$('bag').style.display='none'}
$('bagx').onclick=closeBag;
const shGeo=new THREE.BoxGeometry(.03,.03,.075),shMat=new THREE.MeshBasicMaterial({color:0xd8a83c}),shells=[],puffs=[];
const smT=(()=>{const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d'),g=x.createRadialGradient(32,32,2,32,32,30);g.addColorStop(0,'rgba(255,255,255,.9)');g.addColorStop(.6,'rgba(200,200,200,.45)');g.addColorStop(1,'rgba(200,200,200,0)');x.fillStyle=g;x.fillRect(0,0,64,64);return new THREE.CanvasTexture(c)})();
function spawnShell(){const fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw),rx=Math.cos(P.yaw),rz=-Math.sin(P.yaw);
  const m=new THREE.Mesh(shGeo,shMat);m.position.set(P.x+rx*.22+fx*.45,1.38+P.y,P.z+rz*.22+fz*.45);scene.add(m);
  shells.push({m,v:new THREE.Vector3(rx*(1.8+rnd()*1.4)+fx*(.2+rnd()*.5),2+rnd()*1.5,rz*(1.8+rnd()*1.4)+fz*(.2+rnd()*.5)),sp:8+rnd()*10,l:40,rest:0});
  if(shells.length>50)scene.remove(shells.shift().m)}
function puff(big){cam.updateMatrixWorld();const v=new THREE.Vector3(.3,-.26,-.9);cam.localToWorld(v);
  const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:smT,color:0xb8b8b8,transparent:true,opacity:.55,depthWrite:false}));sp.position.copy(v);sp.scale.setScalar(big?.22:.14);scene.add(sp);
  puffs.push({sp,v:new THREE.Vector3((rnd()-.5)*.25,.5+rnd()*.35,(rnd()-.5)*.25),l:big?2:1.6,t:0,b:big?.22:.14})}
// --- loop ---
const v3=new THREE.Vector3();let last=performance.now();
function frame(t){requestAnimationFrame(frame);let dt=Math.min(.05,(t-last)/1000);last=t;try{chTick(t)}catch(e){}
  if(SAW.on&&(!started||over||paused)){sawEngine(0);SW.ready=0;SW.t=0;SW.n=-1}
  if(started&&!over&&!paused){now+=dt*1000;
    // input
    let f=mv.y+(key.KeyW?1:0)-(key.KeyS?1:0),s=mv.x+(key.KeyD?1:0)-(key.KeyA?1:0);
    if(fin){f=0;s=0}const l=Math.hypot(f,s);if(l>1){f/=l;s/=l}
    const sy=Math.sin(P.yaw),cy=Math.cos(P.yaw);
    let wx=-sy*f+cy*s,wz=-cy*f-sy*s;
    dashCd-=dt;if(hold.dash&&dashCd<=0&&!fin){dashT=.18;dashCd=1.1;const dl=Math.hypot(wx,wz);dvx=dl>.1?wx/dl:-sy;dvz=dl>.1?wz/dl:-cy}
    if(dashT>0){dashT-=dt;wx=dvx*3.6;wz=dvz*3.6}
    P.x+=wx*6*dt;P.z+=wz*6*dt;collide(P,.4);
    if(hold.jmp&&P.y<=0){P.vy=7.5}
    P.vy-=22*dt;P.y=Math.max(0,P.y+P.vy*dt);if(P.y===0&&P.vy<0)P.vy=0;
    $('dash').style.opacity=dashCd>0?.45:1;
    // attack / block
    if(hold.swap&&!swLatch&&swapT<=0&&reload<=0&&atkT<=0&&allowed.length>1&&!fin){swLatch=1;swapT=.3;pendW=nextW();if(pendW===weapon){pendW=-1;swapT=0}}
    if(!hold.swap)swLatch=0;
    if(swapT>0){swapT-=dt;if(pendW>=0&&swapT<.15){weapon=pendW;pendW=-1;setW()}}
    gcd-=dt;recoil=Math.max(0,recoil-dt*6);flashT-=dt;MF.visible=flashT>0;
    if(reload>0){reload-=dt;if(reload<=0){const k=Math.min(12-ammo,inv.ammo);ammo+=k;inv.ammo-=k;sc=0;updAmmo()}}
    const canAct=swapT<=0&&!fin;
    if(weapon===0||weapon===3){
      if(hold.atk&&atkT<=0&&!hold.blk&&canAct){atkT=.32;hitDone=false;fistSide=1-fistSide}
      if(atkT>0){atkT-=dt;if(!hitDone&&atkT<.2){hitDone=true;if(weapon===0)doHit();else fistHit()}}
      if(hold.blk&&atkT<=0&&canAct)blockT+=dt||0.001;else blockT=0;
    }else if(weapon===1){
      blockT=0;
      if(hold.atk&&canAct&&gcd<=0&&reload<=0&&ammo>0)shoot();
      if(hold.atk&&canAct&&ammo<=0)startReload();
      if(hold.blk&&canAct)startReload();
    }else if(weapon===4){
      if(hold.atk&&atkT<=0&&!hold.blk&&canAct&&SW.ready){atkT=.45;hitDone=false;SW.side^=1;sfxSwing()}
      if(atkT>0){atkT-=dt;if(!hitDone&&atkT<.3){hitDone=true;sawHit()}}
      if(hold.blk&&atkT<=0&&canAct&&SW.ready)blockT+=dt||.001;else blockT=0;
    }else{
      blockT=0;
      if(hold.atk&&atkT<=0&&canAct&&inv.knives>0){atkT=.32;hitDone=false}
      if(atkT>0){atkT-=dt;if(!hitDone&&atkT<.15){hitDone=true;throwKnife()}}
    }
    // instructor
    if(lvl===0&&inst){inst.g.rotation.y=0;moved+=Math.hypot(wx,wz)*dt*6;if(dashT>0)dashed=1;if(P.y>.2)jumped=1;
      const T=[['Иди: левый стик / WASD',()=>moved>4],['Тяни экран справа — смотри по сторонам',()=>turned>2.5],['РЫВОК: кнопка слева / Shift',()=>dashed],['ПРЫЖОК: ▲ / Пробел',()=>jumped],['Ударь манекен справа: ⚔ / ЛКМ',()=>hits>=3],['БЛОК: держи 🛡 / ПКМ, когда боец замахнётся ножом',()=>parries>=1]];
      if(tutStep<T.length){const q=T[tutStep];if(now>instNext){say(inst,q[0],2800);instNext=now+3000}toast('Обучение '+(tutStep+1)+'/6: '+q[0],500);
        if(q[1]()){tutStep++;instNext=now+1400;say(inst,tutStep<T.length?'Отлично!':'Готов! Начинаем бой.',1300);if(tutStep>=T.length)setTimeout(()=>showNext(1),1800)}}}
    for(let i=items.length-1;i>=0;i--){const it=items[i];it.sp.position.y=.45+Math.sin(now/300+i)*.08;if(Math.hypot(it.x-P.x,it.z-P.z)<1.1){pick(it);scene.remove(it.sp);items.splice(i,1)}}
    if(sc>=7&&now<smokeUntil&&weapon===1&&now-smokeT>90){smokeT=now;puff(0)}
    for(let i=shells.length-1;i>=0;i--){const h=shells[i],q=h.m.position;
      if(!h.rest){h.v.y-=14*dt;q.addScaledVector(h.v,dt);h.m.rotation.x+=h.sp*dt;h.m.rotation.z+=h.sp*.6*dt;
        if(q.y<=.02){q.y=.02;if(h.v.y<-1.5){h.v.y*=-.4;h.v.x*=.6;h.v.z*=.6}else{h.rest=1;h.m.rotation.set(0,rnd()*6,Math.PI/2)}}}
      h.l-=dt;if(h.l<0){scene.remove(h.m);shells.splice(i,1)}}
    for(let i=puffs.length-1;i>=0;i--){const p=puffs[i];p.t+=dt;const a=p.t/p.l;p.sp.position.addScaledVector(p.v,dt);p.sp.scale.setScalar(p.b*(1+a*3.2));p.sp.material.opacity=.55*(1-a);
      if(a>=1){scene.remove(p.sp);puffs.splice(i,1)}}
    for(let i=projs.length-1;i>=0;i--){const p=projs[i],q=p.m.position;p.l-=dt;p.pv.copy(q);p.v.y-=6*dt;q.addScaledVector(p.v,dt);p.m.lookAt(q.x+p.v.x,q.y+p.v.y,q.z+p.v.z);
      let hit=false,rem=false;
      for(const e of npcs){if(e.dead||e.friendly||e.fin)continue;if(Math.hypot(e.p.x-q.x,e.p.z-q.z)<.45&&q.y>.1&&q.y<1.95){knifeHit(e,q.y);hit=rem=true;break}}
      if(!rem){for(const w of W){if(q.x>w.a-.05&&q.x<w.b+.05&&q.z>w.c-.05&&q.z<w.d+.05){rem=true;break}}}
      if(!rem&&(q.y<.05||p.l<=0))rem=true;
      if(rem){if(!hit)spawnItem('knife',p.pv.x,p.pv.z,1);scene.remove(p.m);projs.splice(i,1)}}
    if(fin){const q=fin,e=q.e,wy=[1.75,1.55,1.15][q.z],fx=-Math.sin(P.yaw),fz=-Math.cos(P.yaw),ox=e.p.x-fx*.25,oz=e.p.z-fz*.25;q.t+=dt;
      if(q.t>=.22&&!q.a){q.a=1;blood(ox,wy,oz,30,-fx*.5,-fz*.5);shake=.1}
      if(q.t>=.55&&!q.b){q.b=1;blood(ox,wy,oz,50,-fx,-fz);shake=.12;decal(e.p.x,e.p.z)}
      if(q.t>=.22&&q.t<1.2&&now-q.g>60){q.g=now;blood(ox,wy,oz,3,-fx*.3,-fz*.3)}
      if(q.t>=1.2){e.hp=1;e.stun=0;e.fin=0;fin=null;dmgE(e,fx,fz,0)}}
    // enemies
    for(const e of npcs){if(e.friendly)continue;
      if(e.dead){e.dt+=dt;const t=e.dt;let nm='lieB',fi=0,rot=1.5708*e.fs;
        if(t<.5){nm='kneel';rot=0}else if(t<1){nm='kneel';fi=1;rot=0}else if(t<1.35){nm='lieF';rot=(t-1)/.35*1.5708*e.fs}else if(t<2.4)nm='lieF';
        const key=nm+fi+(e.wounds?e.wounds.length:0)+(e.nohead?'h':'');if(key!==e.pose){e.pose=key;e.sp.material.map=eTex(e,nm,fi);e.sp.material.needsUpdate=true}
        e.sp.material.rotation=rot;e.sp.position.y=1.1-Math.abs(rot)/1.5708*.75;
        if(e.gush&&t<1.8&&now-(e.gt||0)>70){e.gt=now;blood(e.p.x,(e.wy||1)*(1-Math.min(1,t/1.5)*.6),e.p.z,3,(P.x-e.p.x)*.1,(P.z-e.p.z)*.1)}
        continue}
      const dx=P.x-e.p.x,dz=P.z-e.p.z,d=Math.hypot(dx,dz);e.g.rotation.y=Math.atan2(dx,dz);
      {let nm='idle',fi=0;if(e.fin){nm='fin';fi=e.fz}else if(e.suffer>0){nm='neck';fi=Math.floor(now/260)%2}else if(e.wind>0){nm='wind';fi=Math.min(3,Math.floor((1-e.wind/.9)*4))}else if(e.sk>0){nm='hit';fi=e.sk>.1?0:1;e.sk-=dt}else if(e.stun>0&&e.par){nm='stag';fi=Math.min(2,Math.floor((1.8-e.stun)/.5))}else if(e.moving){nm='walk';fi=Math.floor(now/170)%2}
        e.moving=0;const key=nm+fi+(e.wounds?e.wounds.length:0)+(e.nohead?'h':'');if(key!==e.pose){e.pose=key;e.sp.material.map=eTex(e,nm,fi);e.sp.material.needsUpdate=true}}
      if(e.flash>0){e.flash-=dt;e.ms.forEach(m=>m.material.color.setHex(e.flash>0?0xff5555:m.userData.c))}
      if(e.suffer>0){e.suffer-=dt;if(now-(e.gt||0)>80){e.gt=now;blood(e.p.x,1.5,e.p.z,3,(P.x-e.p.x)*.1,(P.z-e.p.z)*.1)}
      if(e.suffer<=0){e.wy=1.55;e.gush=1;e.hp=1;dmgE(e,0,0,0)}continue}
      if(e.stun>0){e.stun-=dt;if(e.stun<=0)e.par=0;continue}
      if(e.type==='dummy'||(e.type==='trainer'&&tutStep<5))continue;if(e.type==='trainer'||e.aggro||d<9){e.bark-=dt;if(e.bark<0){e.bark=6+rnd()*6;say(e,['Умри!','Стоять!','Тревога!','Он здесь!'][rnd()*4|0],1500)}
        if(d>1.5){const sp=2.8*dt;e.p.x+=dx/d*sp;e.p.z+=dz/d*sp;collide(e.p,.4);e.moving=1;e.g.position.y=Math.abs(Math.sin(now/110))*.06}
        else{e.cd-=dt;if(e.cd<=0&&e.wind<=0){e.wind=.9;e.cd=2.2}}
        if(e.wind>0){e.wind-=dt;e.g.position.z+=0;if(e.wind<=0)strike(e)}}}
    // particles
    for(let i=parts.length-1;i>=0;i--){const m=parts[i],u=m.userData;u.l-=dt;
      if(m.position.y>.05||u.v.y>0){u.v.y-=14*dt;m.position.addScaledVector(u.v,dt);if(u.g)m.rotation.x+=u.v.length()*dt;if(m.position.y<=.05){m.position.y=.05;if(u.g&&u.v.y<-2){u.v.y*=-.3;u.v.x*=.5;u.v.z*=.5}else{u.v.set(0,0,0);if(u.g&&!u.d){u.d=1;decal(m.position.x,m.position.z)}}}}
      if(u.l<0){scene.remove(m);parts.splice(i,1)}}
    $('flash').style.opacity=Math.max(0,+$('flash').style.opacity-dt*2);
    if(tipT&&now>tipT){tip.style.display='none';tipT=0}
    // camera + hands
    const spd=Math.hypot(wx,wz);bobT+=dt*spd*8;
    cam.position.set(P.x+(rnd()-.5)*shake,1.6+P.y+Math.sin(bobT)*.04*Math.min(1,spd)+(rnd()-.5)*shake*.6,P.z);shake=Math.max(0,shake-dt*.5);parryT-=dt;
    cam.rotation.set(P.pitch+kick,P.yaw,0);kick=Math.max(0,kick-dt*.6);
    const fov=75+(dashT>0?14:0);cam.fov+=(fov-cam.fov)*Math.min(1,dt*14);cam.updateProjectionMatrix();
    let isFist=weapon===3;const bob=Math.sin(bobT)*.015;
    let rp=isFist?[.48,-.30,-.55]:[.343,-.28,-.55],rr=[0,0,0],lp=isFist?[-.48,-.28,-.55]:[-.332,-.242,-.55];
    if(blockT>0){lp=isFist?[-.18,-.05,parryT>0?-.62:-.48]:[-.05,-.02,parryT>0?-.62:-.45]; if(isFist) rp=[.18,-.05,parryT>0?-.62:-.48];}
    if(atkT>0){const p=1-atkT/.32,sw=Math.sin(p*Math.PI);
      if(isFist){ // alternate punch: right or left extends
        if(fistSide){rp=[.48-.4*p,-.30+.12*sw,-.55-.2*sw];rr=[.2*sw,-.2*sw,.4-1.0*p];lp=[-.48,-.28+bob,-.55];}
        else{lp=[-.48+.4*p,-.28+.12*sw,-.55-.2*sw];rr=[0,0,0];rp=[.48,-.30+bob,-.55];}
      }else{rp=[.343-.55*p,-.28+.06*sw,-.55-.15*sw];rr=[0,-.3*sw,.55-1.1*p]}
    }
    if(fin){const t=fin.t,zy=[.06,0,-.1][fin.z],rz=[.45,.12,-.25][fin.z],L=(a,b,u)=>a+(b-a)*u;let u=t<.22?t/.22:(t<.55?1:Math.max(0,1-(t-.55)/.35));u=Math.min(1,u);
      rp=[L(.343,-.3,u)+(t>.22&&t<.55?Math.sin(t*90)*.005:0),L(-.28,zy-.36*Math.sin(rz-.26),u),L(-.55,-.62,u)];rr=[0,0,L(0,rz,u)];lp=[-.2,-.12,-.55]}
    const dip=swapT>0?Math.sin(Math.PI*(1-swapT/.3))*.6:0;
    if(weapon===1)lp=[.12,-.3,-.5];
    rp[1]-=dip;lp[1]-=dip;
    const k=Math.min(1,dt*(atkT>0?40:16));
    hAcc+=dt;if(hAcc>=.08){const kk=Math.min(1,(atkT>0?40:16)*hAcc),J=()=>(rnd()-.5)*.012;hAcc=0;
    const hands=isFist?[F_RH,F_LH]:[RH,LH];
    hands[0].position.x+=(rp[0]-hands[0].position.x)*kk;hands[0].position.y+=(rp[1]+bob-hands[0].position.y)*kk;hands[0].position.z+=(rp[2]-hands[0].position.z)*kk;
    hands[0].rotation.x+=(rr[0]-hands[0].rotation.x)*kk;hands[0].rotation.y+=(rr[1]-hands[0].rotation.y)*kk;hands[0].rotation.z+=(rr[2]-hands[0].rotation.z)*kk;
    hands[1].position.x+=(lp[0]-hands[1].position.x)*kk;hands[1].position.y+=(lp[1]+bob-hands[1].position.y)*kk;hands[1].position.z+=(lp[2]-hands[1].position.z)*kk;
    hands[0].position.x+=J();hands[0].position.y+=J();hands[1].position.x+=J();hands[1].position.y+=J();hands[0].rotation.z+=J()*2;}
    const rl=reload>0?Math.sin(Math.PI*(1-reload/1.2)):0;
    // textured pistol (both hands) + reload anim (left-hand mag feel)
    {const rt=reload>0?1-reload/1.2:0;const rS=Math.sin(rt*Math.PI);
      G_IDLE.visible=true;G_FIRE.visible=false;
      PG.position.set(.04-rS*.12,-.43+bob-dip-rS*.38+recoil*.04,-.58+recoil*.18);
      PG.rotation.set(recoil*.45+rS*.55,0,rS*.4+recoil*.06);
      if(flashT>0)PG.position.z+=.03;}
    if(weapon===4)sawFrame(dt,bob,dip);
// bubbles
    for(const n of npcs){if(n.el.style.display==='none')continue;
      if(n.until<now||n.dead){n.el.style.display='none';continue}
      v3.set(n.p.x,n.p.y+2.35,n.p.z).project(cam);
      if(v3.z>1||Math.hypot(n.p.x-P.x,n.p.z-P.z)>14){n.el.style.visibility='hidden';continue}
      n.el.style.visibility='visible';
      n.el.style.transform=`translate(-50%,-100%) translate(${(v3.x*.5+.5)*innerWidth}px,${(-v3.y*.5+.5)*innerHeight}px)`}
  }
  R.render(scene,cam)}
requestAnimationFrame(frame);
